import { CountryFlag, Continent } from '../types';
import { countriesEurope } from './countriesEurope';
import { countriesAmericas } from './countriesAmericas';
import { countriesAsia } from './countriesAsia';
import { countriesAfrica } from './countriesAfrica';
import { countriesOceania } from './countriesOceania';
import { countriesExtra } from './countriesExtra';
import { countriesRemainder } from './countriesRemainder';

// Consolidate all country datasets into one master world registry
const combinedList: CountryFlag[] = [
  ...countriesEurope,
  ...countriesAmericas,
  ...countriesAsia,
  ...countriesAfrica,
  ...countriesOceania,
  ...countriesExtra,
  ...countriesRemainder,
];

// Deduplicate by country ID if any overlaps exist
const countryMap = new Map<string, CountryFlag>();
for (const c of combinedList) {
  if (!countryMap.has(c.id)) {
    countryMap.set(c.id, c);
  }
}

export const ALL_COUNTRIES: CountryFlag[] = Array.from(countryMap.values());

export function getCountryById(id: string): CountryFlag | undefined {
  return countryMap.get(id.toLowerCase());
}

export function getCountriesByContinent(continent: Continent): CountryFlag[] {
  return ALL_COUNTRIES.filter((c) => c.continent === continent);
}

export function getDifficultCountries(): CountryFlag[] {
  return ALL_COUNTRIES.filter((c) => c.difficulty >= 3);
}

export function getRandomCountry(excludeId?: string, continent?: Continent, onlyDifficult?: boolean): CountryFlag {
  let pool = ALL_COUNTRIES;
  if (continent) {
    pool = pool.filter((c) => c.continent === continent);
  }
  if (onlyDifficult) {
    pool = pool.filter((c) => c.difficulty >= 3);
  }
  if (excludeId && pool.length > 1) {
    pool = pool.filter((c) => c.id !== excludeId);
  }
  const index = Math.floor(Math.random() * pool.length);
  return pool[index] || ALL_COUNTRIES[0];
}

/**
 * Returns flag image URL from flagcdn
 */
export function getFlagImageUrl(countryId: string): string {
  return `https://flagcdn.com/w640/${countryId.toLowerCase()}.png`;
}

/**
 * Returns high-res SVG URL from flagcdn
 */
export function getFlagSvgUrl(countryId: string): string {
  return `https://flagcdn.com/${countryId.toLowerCase()}.svg`;
}
