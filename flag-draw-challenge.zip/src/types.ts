export type Continent = 'Europa' | 'América' | 'Asia' | 'África' | 'Oceanía';

export type Difficulty = 'facil' | 'normal' | 'dificil' | 'extremo';

export type GameMode =
  | 'aleatorio'
  | 'continente'
  | 'todas'
  | 'dificiles'
  | 'contrarreloj'
  | 'racha'
  | 'extremo'
  | 'practicar'
  | 'speedrun';

export interface SpeedrunRecord {
  id: string;
  countryId: string;
  countryName: string;
  countryEmoji: string;
  userName: string;
  userAvatar?: string;
  userEmail?: string;
  userId?: string;
  score: number; // 0 - 100 (Primary ranking: highest score wins)
  timeSeconds: number; // e.g. 14.32s (Tiebreaker: lowest time wins)
  date: string; // ISO date string
  isPlayer?: boolean;
}

export type ToolType = 'brush' | 'eraser' | 'fill' | 'line' | 'rect' | 'circle' | 'star';

export interface OfficialColor {
  name: string;
  hex: string;
  role?: string;
  approxPercent?: number;
}

export type FlagStructureType =
  | 'horizontal_stripes'
  | 'vertical_stripes'
  | 'cross'
  | 'nordic_cross'
  | 'saltire'
  | 'canton'
  | 'triangle_hoist'
  | 'circle_center'
  | 'plain'
  | 'diagonal'
  | 'complex';

export interface FlagStructure {
  type: FlagStructureType;
  stripeCount?: number;
  stripeOrientation?: 'horizontal' | 'vertical' | 'diagonal';
  stripeColors?: string[]; // hex codes from top to bottom or left to right
  stripeRatios?: number[]; // e.g. [1, 2, 1] for Spain or [2, 1, 1] for Colombia
  cantonColor?: string;
  cantonRatio?: { width: number; height: number }; // relative to flag (e.g. 0.4, 0.5)
  triangleColor?: string;
  triangleWidthRatio?: number; // hoist triangle width (e.g. 0.433)
  backgroundColor?: string;
}

export interface FlagSymbol {
  type:
    | 'star'
    | 'sun'
    | 'crescent'
    | 'shield'
    | 'cross'
    | 'eagle'
    | 'dragon'
    | 'leaf'
    | 'chakra'
    | 'circle'
    | 'emblem'
    | 'text'
    | 'weapon'
    | 'triangle'
    | 'other';
  name: string;
  color: string;
  approxX: number; // 0 to 1 relative to flag width
  approxY: number; // 0 to 1 relative to flag height
  relativeSize: number; // relative size (0.1 = 10% of width)
  count?: number;
  required?: boolean;
}

export interface CountryFlag {
  id: string; // ISO 3166-1 alpha-2 lower-case (e.g. "es", "fr")
  name: string; // Spanish name
  englishName: string;
  continent: Continent;
  aspectRatio: string; // e.g. "2:3", "1:2", "3:5", "1:1", "10:19"
  ratioValue: number; // width / height (e.g. 1.5 for 2:3)
  officialColors: OfficialColor[];
  structure: FlagStructure;
  symbols: FlagSymbol[];
  difficulty: 1 | 2 | 3 | 4 | 5;
  description: string;
  tips?: string;
}

export interface EvaluationDetailItem {
  type: 'success' | 'error' | 'warning';
  title: string;
  description: string;
  category: 'color' | 'structure' | 'symbols' | 'position' | 'proportions';
  pointsChange: number; // positive or negative
}

export interface EvaluationCategoryScores {
  colors: number; // 0 - 100
  structure: number; // 0 - 100
  symbols: number; // 0 - 100
  proportions: number; // 0 - 100
}

export interface EvaluationResult {
  score: number; // 0 - 100
  tier: 'perfect' | 'excellent' | 'good' | 'partial' | 'poor' | 'wrong';
  tierLabel: string;
  tierColor: string;
  categoryScores: EvaluationCategoryScores;
  feedbackItems: EvaluationDetailItem[];
  userImageBase64: string;
  referenceImageBase64: string;
  isExtreme: boolean;
  drawnPixelsPercentage: number;
  hintsUsed?: number;
  isPassed: boolean; // >= 90 required to pass and keep streak
}

export interface GameStats {
  totalDrawn: number;
  flagsCompleted: number;
  perfectScores: number;
  currentStreak: number;
  bestStreak: number;
  completedFlags: Record<string, number>;
}

export interface UserStats {
  totalDrawn: number;
  perfectFlags: number; // >= 95
  completedFlags: number; // >= 70
  failedFlags: number; // < 50
  bestScore: number;
  totalScoreSum: number;
  averageScore: number;
  currentStreak: number;
  maxStreak: number;
  totalTimeSeconds: number;
  averageTimeSeconds: number;
}

export interface CountryProgress {
  countryId: string;
  bestScore: number;
  attempts: number;
  lastDrawnDate: string;
  passed: boolean;
  medal?: 'gold' | 'silver' | 'bronze';
}
