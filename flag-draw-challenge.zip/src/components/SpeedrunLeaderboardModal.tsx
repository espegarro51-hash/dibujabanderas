import React, { useState, useMemo, useEffect } from 'react';
import { CountryFlag } from '../types';
import { ALL_COUNTRIES } from '../data/countries';
import { getCountryLeaderboard, formatSpeedrunTime } from '../utils/speedrun';
import { getCountryFlagEmoji } from '../utils/emojiUtils';
import { Trophy, Timer, X, Search, Medal, Sparkles, Flame, User } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface SpeedrunLeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCountry?: CountryFlag;
  initialCountry?: CountryFlag;
  onSelectCountryToSpeedrun?: (country: CountryFlag) => void;
  onSelectSpeedrunCountry?: (country: CountryFlag) => void;
}

export const SpeedrunLeaderboardModal: React.FC<SpeedrunLeaderboardModalProps> = ({
  isOpen,
  onClose,
  currentCountry,
  initialCountry,
  onSelectCountryToSpeedrun,
  onSelectSpeedrunCountry,
}) => {
  const baseCountry = initialCountry || currentCountry || ALL_COUNTRIES[0];
  const [selectedCountryId, setSelectedCountryId] = useState<string>(baseCountry.id);
  const [searchTerm, setSearchTerm] = useState<string>('');

  useEffect(() => {
    if (baseCountry) {
      setSelectedCountryId(baseCountry.id);
    }
  }, [baseCountry.id]);

  const onSelect = onSelectSpeedrunCountry || onSelectCountryToSpeedrun;

  const targetCountry = useMemo(() => {
    return ALL_COUNTRIES.find((c) => c.id === selectedCountryId) || baseCountry;
  }, [selectedCountryId, baseCountry]);

  const leaderboard = useMemo(() => {
    return getCountryLeaderboard(targetCountry.id, targetCountry.name);
  }, [targetCountry]);

  // Countries filtered for the quick switcher
  const filteredCountries = useMemo(() => {
    if (!searchTerm.trim()) return ALL_COUNTRIES.slice(0, 20);
    const q = searchTerm.toLowerCase();
    return ALL_COUNTRIES.filter(
      (c) => c.name.toLowerCase().includes(q) || c.englishName.toLowerCase().includes(q)
    ).slice(0, 30);
  }, [searchTerm]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-neutral-900 border border-neutral-800 w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                <span>Clasificación Speedrun</span>
                <span className="text-xl">{getCountryFlagEmoji(targetCountry.id)}</span>
              </h2>
              <p className="text-xs text-neutral-400">
                Récords oficiales de <strong className="text-white">{targetCountry.name}</strong>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tiebreaker Rule Callout Banner */}
        <div className="px-4 py-2.5 bg-gradient-to-r from-amber-500/10 via-amber-400/5 to-transparent border-b border-amber-500/20 flex items-center gap-2.5 text-xs text-amber-300">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>Criterio oficial:</strong> Gana la mayor nota (puntuación). En caso de empate a puntos, el desempate se decide por <strong>menor tiempo</strong>.
          </span>
        </div>

        {/* Country Quick Switcher Bar */}
        <div className="p-3 sm:p-4 border-b border-neutral-800 bg-neutral-900/90 flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar otra bandera..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="w-full flex-1 flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-thin">
            {filteredCountries.slice(0, 6).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  setSelectedCountryId(c.id);
                  setSearchTerm('');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
                  selectedCountryId === c.id
                    ? 'bg-amber-500 text-neutral-950 shadow-md font-bold'
                    : 'bg-neutral-950 hover:bg-neutral-800 text-neutral-300 border border-neutral-800'
                }`}
              >
                <span>{getCountryFlagEmoji(c.id)}</span>
                <span>{c.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Leaderboard Table Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {leaderboard.length === 0 ? (
            <div className="text-center py-12 text-neutral-400 text-sm">
              No hay tiempos registrados aún para {targetCountry.name}. ¡Sé el primero en completarla!
            </div>
          ) : (
            <div className="space-y-2">
              {leaderboard.map((entry, index) => {
                const rank = index + 1;
                const isFirst = rank === 1;
                const isPodium = rank <= 3;
                const isPlayer = entry.isPlayer;

                return (
                  <div
                    key={entry.id}
                    className={`flex items-center justify-between p-3 sm:p-4 rounded-2xl border transition-all ${
                      isFirst
                        ? 'bg-amber-500/10 border-amber-500/40 shadow-lg shadow-amber-500/5'
                        : isPlayer
                        ? 'bg-blue-500/10 border-blue-500/40 ring-1 ring-blue-500/30'
                        : 'bg-neutral-950/60 border-neutral-800/80 hover:border-neutral-700'
                    }`}
                  >
                    {/* Rank & Player Info */}
                    <div className="flex items-center gap-3 sm:gap-4">
                      {/* Rank Badge */}
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm">
                        {rank === 1 ? (
                          <span className="text-lg">🥇</span>
                        ) : rank === 2 ? (
                          <span className="text-lg">🥈</span>
                        ) : rank === 3 ? (
                          <span className="text-lg">🥉</span>
                        ) : (
                          <span className="text-neutral-400 font-bold">{rank}º</span>
                        )}
                      </div>

                      {/* Avatar & Name */}
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-sm">
                          {entry.userAvatar ? entry.userAvatar : <User className="w-4 h-4 text-neutral-400" />}
                        </div>
                        <div>
                          <div className="font-bold text-sm text-white flex items-center gap-2">
                            <span>{entry.userName}</span>
                            {isPlayer && (
                              <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded font-semibold">
                                TÚ
                              </span>
                            )}
                            {isFirst && (
                              <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded font-semibold flex items-center gap-1">
                                <Flame className="w-3 h-3 fill-current" />
                                RÉCORD
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-neutral-500">
                            {new Date(entry.date).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Stats: Score & Time */}
                    <div className="flex items-center gap-4 sm:gap-6 text-right">
                      {/* Score */}
                      <div>
                        <div className="text-[10px] text-neutral-400 font-semibold uppercase">Nota</div>
                        <div
                          className={`font-black text-base sm:text-lg ${
                            entry.score >= 95
                              ? 'text-emerald-400'
                              : entry.score >= 90
                              ? 'text-amber-400'
                              : 'text-neutral-300'
                          }`}
                        >
                          {entry.score}
                          <span className="text-xs font-medium text-neutral-500">/100</span>
                        </div>
                      </div>

                      {/* Time */}
                      <div className="min-w-[70px]">
                        <div className="text-[10px] text-neutral-400 font-semibold uppercase flex items-center justify-end gap-1">
                          <Timer className="w-3 h-3" />
                          <span>Tiempo</span>
                        </div>
                        <div className="font-mono font-black text-sm sm:text-base text-neutral-100">
                          {formatSpeedrunTime(entry.timeSeconds)}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer Action */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/80 flex items-center justify-between">
          <div className="text-xs text-neutral-400">
            Bandera actual: <strong className="text-white">{targetCountry.name}</strong>
          </div>

          {onSelect && (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onSelect(targetCountry);
                onClose();
              }}
              className="bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black px-5 py-2 rounded-xl text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Timer className="w-4 h-4" />
              <span>Jugar Speedrun de {targetCountry.name}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
