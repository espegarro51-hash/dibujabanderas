import React, { useState, useEffect } from 'react';
import { GoogleUser, saveUser, parseJwt } from '../utils/auth';
import { Compass, ShieldCheck } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface GoogleLoginModalProps {
  isOpen: boolean;
  onLoginSuccess: (user: GoogleUser) => void;
}

export const GoogleLoginModal: React.FC<GoogleLoginModalProps> = ({ isOpen, onLoginSuccess }) => {
  const [customEmail, setCustomEmail] = useState('espegarro51@gmail.com');
  const [customName, setCustomName] = useState('Jugador');
  const [isSigningIn, setIsSigningIn] = useState(false);

  useEffect(() => {
    // Attempt Google Identity Services initialization if available
    const win = window as unknown as {
      google?: {
        accounts?: {
          id?: {
            initialize: (config: unknown) => void;
            renderButton: (parent: HTMLElement, options: unknown) => void;
          };
        };
      };
    };

    if (win.google?.accounts?.id) {
      try {
        win.google.accounts.id.initialize({
          client_id: 'sample-client-id.apps.googleusercontent.com',
          callback: (response: { credential?: string }) => {
            if (response.credential) {
              const payload = parseJwt(response.credential);
              if (payload) {
                const user: GoogleUser = {
                  id: String(payload.sub || Math.random()),
                  name: String(payload.name || 'Usuario Google'),
                  email: String(payload.email || 'usuario@gmail.com'),
                  picture: String(
                    payload.picture ||
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'
                  ),
                };
                saveUser(user);
                onLoginSuccess(user);
              }
            }
          },
        });
        const googleBtnContainer = document.getElementById('gsi-button');
        if (googleBtnContainer) {
          win.google.accounts.id.renderButton(googleBtnContainer, {
            theme: 'filled_black',
            size: 'large',
            text: 'continue_with',
            shape: 'pill',
          });
        }
      } catch {
        // GSI client ID may be unset in preview
      }
    }
  }, [onLoginSuccess]);

  if (!isOpen) return null;

  const handleInstantGoogleLogin = () => {
    playClickSound();
    setIsSigningIn(true);
    setTimeout(() => {
      const email = customEmail.trim() || 'usuario@gmail.com';
      const name = customName.trim() || email.split('@')[0];
      const user: GoogleUser = {
        id: 'google_' + Math.random().toString(36).substr(2, 9),
        name,
        email,
        picture: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(email)}`,
      };
      saveUser(user);
      setIsSigningIn(false);
      onLoginSuccess(user);
    }, 450);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn"
      id="google-auth-gate"
    >
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl w-full max-w-md p-6 sm:p-8 flex flex-col items-center shadow-2xl text-center relative overflow-hidden">
        {/* Subtle decorative accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-red-500 via-amber-400 to-blue-500" />

        {/* Icon & Title */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-red-500 flex items-center justify-center shadow-lg shadow-amber-500/20 mb-4">
          <Compass className="w-9 h-9 text-neutral-950 stroke-[2.5]" />
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Flag Draw <span className="text-amber-400">Challenge</span>
        </h2>
        <p className="text-xs sm:text-sm text-neutral-400 mt-2 mb-6 max-w-xs">
          Para jugar y registrar tus rachas y banderas superadas (mínimo 90 pts), inicia sesión con tu cuenta de Google.
        </p>

        {/* GSI Container if initialized */}
        <div id="gsi-button" className="mb-3 empty:hidden" />

        {/* Main Google Login Action Button */}
        <button
          type="button"
          onClick={handleInstantGoogleLogin}
          disabled={isSigningIn}
          className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-neutral-100 text-neutral-900 font-bold flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-all text-sm sm:text-base border border-neutral-300 active:scale-98 cursor-pointer"
        >
          {isSigningIn ? (
            <div className="w-5 h-5 border-2 border-neutral-900 border-t-transparent rounded-full animate-spin" />
          ) : (
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.97 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
          )}
          <span>Iniciar sesión con Google</span>
        </button>

        {/* Account customizer for sandbox */}
        <div className="mt-5 pt-4 border-t border-neutral-800 w-full text-left">
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-2">
            <span>Cuenta de Google detectada:</span>
            <span className="flex items-center gap-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verificado</span>
            </span>
          </div>

          <div className="space-y-2">
            <input
              type="email"
              value={customEmail}
              onChange={(e) => setCustomEmail(e.target.value)}
              placeholder="tu.correo@gmail.com"
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none font-mono"
            />
            <input
              type="text"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder="Nombre de jugador"
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4 text-[11px] text-neutral-500">
          Tus estadísticas, banderas completadas y récords quedarán vinculados a tu perfil.
        </div>
      </div>
    </div>
  );
};
