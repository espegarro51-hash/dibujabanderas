import React, { useState, useMemo } from 'react';
import { CountryFlag, Continent } from '../types';
import { ALL_COUNTRIES } from '../data/countries';
import { getCountryFlagEmoji } from '../utils/emojiUtils';
import { Search, X, Globe, Filter, Check, Star } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface CountrySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCountry: (country: CountryFlag) => void;
  completedFlags: Record<string, number>; // countryId -> best score
  currentCountryId: string;
}

const CONTINENTS: (Continent | 'Todos')[] = ['Todos', 'Europa', 'América', 'Asia', 'África', 'Oceanía'];

export const CountrySelectorModal: React.FC<CountrySelectorModalProps> = ({
  isOpen,
  onClose,
  onSelectCountry,
  completedFlags,
  currentCountryId,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContinent, setSelectedContinent] = useState<Continent | 'Todos'>('Todos');
  const [difficultyFilter, setDifficultyFilter] = useState<number | 'all'>('all');

  const filteredCountries = useMemo(() => {
    return ALL_COUNTRIES.filter((c) => {
      // Search
      const matchSearch =
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.englishName.toLowerCase().includes(searchTerm.toLowerCase());
      if (!matchSearch) return false;

      // Continent
      if (selectedContinent !== 'Todos' && c.continent !== selectedContinent) {
        return false;
      }

      // Difficulty
      if (difficultyFilter !== 'all' && c.difficulty !== difficultyFilter) {
        return false;
      }

      return true;
    });
  }, [searchTerm, selectedContinent, difficultyFilter]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto animate-fadeIn"
      id="country-selector-modal"
    >
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-neutral-100">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg sm:text-xl font-bold text-white">
              Atlas Mundial de Banderas ({ALL_COUNTRIES.length} Países)
            </h3>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 bg-neutral-950/80 border-b border-neutral-800 flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por nombre en español o inglés (ej: España, Japón, Brasil...)"
              className="w-full pl-9 pr-4 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>

          {/* Continent Filter */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {CONTINENTS.map((cont) => (
              <button
                key={cont}
                type="button"
                onClick={() => {
                  playClickSound();
                  setSelectedContinent(cont);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedContinent === cont
                    ? 'bg-amber-500 text-neutral-950'
                    : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                {cont}
              </button>
            ))}
          </div>

          {/* Difficulty Filter */}
          <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-lg border border-neutral-800 self-start sm:self-auto">
            <Filter className="w-3.5 h-3.5 text-neutral-500 ml-1" />
            <button
              type="button"
              onClick={() => setDifficultyFilter('all')}
              className={`px-2 py-1 rounded text-xs font-medium ${
                difficultyFilter === 'all' ? 'bg-neutral-700 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Todos
            </button>
            {[1, 2, 3, 4, 5].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setDifficultyFilter(d)}
                className={`px-2 py-1 rounded text-xs font-medium ${
                  difficultyFilter === d ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {d}★
              </button>
            ))}
          </div>
        </div>

        {/* Country Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {filteredCountries.map((c) => {
            const bestScore = completedFlags[c.id];
            const isCurrent = c.id === currentCountryId;

            return (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  onSelectCountry(c);
                  onClose();
                }}
                className={`flex flex-col items-center p-3 rounded-xl border text-left transition-all hover:scale-102 hover:shadow-lg cursor-pointer ${
                  isCurrent
                    ? 'bg-amber-950/40 border-amber-500 ring-1 ring-amber-500'
                    : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                {/* Country Flag Emoji Only (No flag images so the user has to draw it from memory) */}
                <div className="w-full py-3 rounded-xl bg-neutral-900/90 border border-neutral-800 mb-2 shadow-xs flex items-center justify-center">
                  <span className="text-4xl sm:text-5xl select-none filter drop-shadow-sm transition-transform hover:scale-110">
                    {getCountryFlagEmoji(c.id)}
                  </span>
                </div>

                {/* Country Name & Continent */}
                <div className="w-full">
                  <div className="font-bold text-xs sm:text-sm text-white truncate text-center">
                    {c.name}
                  </div>
                  <div className="flex items-center justify-between mt-1 text-[10px] text-neutral-400">
                    <span>{c.continent}</span>
                    <div className="flex items-center text-amber-400">
                      <span>{c.difficulty}</span>
                      <Star className="w-2.5 h-2.5 fill-current ml-0.5" />
                    </div>
                  </div>

                  {/* Best score badge if previously attempted (min 90 for completed) */}
                  {bestScore !== undefined && (
                    <div className="mt-1.5 flex items-center justify-center gap-1 text-[10px] font-bold py-0.5 px-2 rounded-full bg-neutral-900 border border-neutral-700">
                      {bestScore >= 90 ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : null}
                      <span className={bestScore >= 90 ? 'text-emerald-400' : 'text-neutral-400'}>
                        {bestScore >= 90 ? 'Completada: ' : 'Récord: '}{bestScore} pts
                      </span>
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between text-xs text-neutral-400">
          <span>Mostrando {filteredCountries.length} de {ALL_COUNTRIES.length} banderas</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-medium transition-colors"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
