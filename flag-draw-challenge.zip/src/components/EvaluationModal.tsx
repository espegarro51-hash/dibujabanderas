import React, { useState } from 'react';
import { CountryFlag, EvaluationResult, GameMode, SpeedrunRecord } from '../types';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  ArrowRight,
  Sparkles,
  Layers,
  Palette,
  Shapes,
  Sliders,
  Share2,
  Timer,
  Trophy,
  Zap,
  Flame,
  User,
} from 'lucide-react';
import { playClickSound } from '../utils/audio';
import { formatSpeedrunTime } from '../utils/speedrun';
import { getCountryFlagEmoji } from '../utils/emojiUtils';

interface EvaluationModalProps {
  country: CountryFlag;
  result: EvaluationResult;
  mode?: GameMode;
  speedrunTime?: number;
  speedrunRankInfo?: {
    rank: number;
    isPodium: boolean;
    isFirstPlace: boolean;
    leaderboard: SpeedrunRecord[];
  } | null;
  onRetry: (keepDrawing: boolean) => void;
  onNext: () => void;
  onSpeedrunRetry?: () => void;
  onOpenSpeedrunPicker?: () => void;
}

export const EvaluationModal: React.FC<EvaluationModalProps> = ({
  country,
  result,
  mode,
  speedrunTime,
  speedrunRankInfo,
  onRetry,
  onNext,
  onSpeedrunRetry,
  onOpenSpeedrunPicker,
}) => {
  const isSpeedrun = mode === 'speedrun';
  const [sliderPos, setSliderPos] = useState<number>(50); // For visual split comparison
  const [activeTab, setActiveTab] = useState<'comparison' | 'details' | 'leaderboard' | 'flagInfo'>(
    isSpeedrun ? 'leaderboard' : 'comparison'
  );
  const [copied, setCopied] = useState<boolean>(false);

  const handleShare = () => {
    playClickSound();
    let text = `Dibujé la bandera de ${country.name} en Flag Draw Challenge y obtuve ${result.score}/100 (${result.tierLabel})! 🎨🚩`;
    if (isSpeedrun && speedrunTime) {
      text = `⚡ SPEEDRUN: ¡Conseguí puesto #${speedrunRankInfo?.rank || 1} en ${country.name} con ${result.score}/100 pts en ${formatSpeedrunTime(speedrunTime)}! 🚩🏁`;
    }
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn"
      id="evaluation-modal"
    >
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-neutral-100">
        {/* Header with Score & Tier Badge */}
        <div className="p-4 sm:p-6 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-4 bg-neutral-950/60">
          <div>
            <div className="flex items-center gap-2 mb-1">
              {isSpeedrun ? (
                <span className="text-xs uppercase tracking-wider font-bold text-amber-400 flex items-center gap-1.5 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  <span>Modo Speedrun Oficial</span>
                </span>
              ) : (
                <span className="text-xs uppercase tracking-wider font-semibold text-neutral-400">
                  Resultado de la corrección
                </span>
              )}
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
              <span>{country.name}</span>
              <span className="text-xl">{getCountryFlagEmoji(country.id)}</span>
              <span className="text-sm font-normal text-neutral-400">({country.continent})</span>
            </h2>
          </div>

          {/* Big Score Block / Speedrun Performance Card */}
          <div className="flex items-center gap-3 sm:gap-4 flex-wrap justify-end">
            {isSpeedrun && speedrunTime !== undefined && (
              <div className="bg-neutral-950 border border-amber-500/30 px-3.5 py-2 rounded-2xl flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Timer className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase font-semibold">Tiempo Final</div>
                  <div className="font-mono font-black text-base text-amber-400">
                    {formatSpeedrunTime(speedrunTime)}
                  </div>
                </div>
              </div>
            )}

            {isSpeedrun && speedrunRankInfo && (
              <div className="bg-neutral-950 border border-neutral-700 px-3.5 py-2 rounded-2xl flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-neutral-800 text-white flex items-center justify-center font-black text-base">
                  {speedrunRankInfo.rank === 1 ? '🥇' : speedrunRankInfo.rank === 2 ? '🥈' : speedrunRankInfo.rank === 3 ? '🥉' : `#${speedrunRankInfo.rank}`}
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase font-semibold">Puesto</div>
                  <div className="font-black text-base text-white">
                    {speedrunRankInfo.rank === 1 ? '¡1º Récord!' : `${speedrunRankInfo.rank}º Lugar`}
                  </div>
                </div>
              </div>
            )}

            <div className="text-right">
              <div
                className="text-xs font-bold uppercase tracking-wide px-2.5 py-1 rounded-full inline-block mb-1 border"
                style={{
                  backgroundColor: `${result.tierColor}20`,
                  color: result.tierColor,
                  borderColor: `${result.tierColor}50`,
                }}
              >
                {result.tierLabel}
              </div>
              <div className="text-xs font-semibold">
                {result.score >= 90 ? (
                  <span className="text-emerald-400">¡Superada! (≥ 90 pts)</span>
                ) : (
                  <span className="text-neutral-400">No superada (requiere ≥ 90 pts)</span>
                )}
              </div>
            </div>

            <div
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex flex-col items-center justify-center border-2 shadow-inner"
              style={{
                borderColor: result.tierColor,
                backgroundColor: `${result.tierColor}15`,
              }}
            >
              <span className="text-2xl sm:text-3xl font-black" style={{ color: result.tierColor }}>
                {result.score}
              </span>
              <span className="text-[10px] text-neutral-400 font-semibold uppercase">/ 100</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-950 px-4 gap-2 overflow-x-auto scrollbar-thin">
          {isSpeedrun && (
            <button
              type="button"
              onClick={() => setActiveTab('leaderboard')}
              className={`py-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'leaderboard'
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>Clasificación ({country.name})</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveTab('comparison')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'comparison'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Comparación Visual</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('details')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'details'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Desglose ({result.feedbackItems.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('flagInfo')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'flagInfo'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>Colores y Datos</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* Speedrun Leaderboard Tab */}
          {activeTab === 'leaderboard' && (
            <div className="space-y-4">
              {/* Ranking Criteria Callout */}
              <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center gap-3 text-xs text-amber-300">
                <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold text-amber-200">Criterio Oficial Speedrun:</span>{' '}
                  Gana quien obtenga la <strong>mayor nota (puntuación)</strong>. Si dos jugadores tienen la misma nota,{' '}
                  <strong>el desempate se decide por menor tiempo</strong>.
                </div>
              </div>

              {/* Player Result Summary Card */}
              {speedrunTime !== undefined && speedrunRankInfo && (
                <div className="bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950 p-4 rounded-2xl border border-amber-500/40 flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-2xl font-black">
                      {speedrunRankInfo.rank === 1 ? '🥇' : speedrunRankInfo.rank === 2 ? '🥈' : speedrunRankInfo.rank === 3 ? '🥉' : `#${speedrunRankInfo.rank}`}
                    </div>
                    <div>
                      <div className="text-xs text-neutral-400 uppercase font-semibold">Tu Puesto Oficial</div>
                      <div className="text-base font-black text-white flex items-center gap-2">
                        <span>
                          {speedrunRankInfo.rank === 1
                            ? '¡1º Puesto: Récord Absoluto!'
                            : `Puesto #${speedrunRankInfo.rank} en ${country.name}`}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 text-right">
                    <div>
                      <div className="text-[10px] text-neutral-400 uppercase font-semibold">Tu Nota</div>
                      <div className="text-lg font-black text-amber-400">{result.score}/100</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-neutral-400 uppercase font-semibold">Tu Tiempo</div>
                      <div className="text-lg font-black font-mono text-white">
                        {formatSpeedrunTime(speedrunTime)}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Leaderboard Table */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                  Top Clasificación · {country.name}
                </h3>
                {(speedrunRankInfo?.leaderboard || []).slice(0, 10).map((entry, idx) => {
                  const rank = idx + 1;
                  const isFirst = rank === 1;
                  const isPlayer = entry.isPlayer;

                  return (
                    <div
                      key={entry.id}
                      className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                        isFirst
                          ? 'bg-amber-500/10 border-amber-500/40 shadow-sm'
                          : isPlayer
                          ? 'bg-blue-500/10 border-blue-500/40 ring-1 ring-blue-500/30'
                          : 'bg-neutral-950/60 border-neutral-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-7 h-7 rounded-xl flex items-center justify-center font-bold text-sm">
                          {rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : `${rank}º`}
                        </div>
                        <div className="w-7 h-7 rounded-full bg-neutral-800 flex items-center justify-center text-xs">
                          {entry.userAvatar || <User className="w-3.5 h-3.5 text-neutral-400" />}
                        </div>
                        <div>
                          <div className="font-bold text-xs sm:text-sm text-white flex items-center gap-2">
                            <span>{entry.userName}</span>
                            {isPlayer && (
                              <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded font-semibold">
                                TÚ
                              </span>
                            )}
                            {isFirst && (
                              <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded font-semibold flex items-center gap-1">
                                <Flame className="w-3 h-3 fill-current" />
                                RÉCORD
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-neutral-500">
                            {new Date(entry.date).toLocaleDateString()}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-right">
                        <div>
                          <div className="text-[9px] text-neutral-400 uppercase font-semibold">Nota</div>
                          <div className="font-black text-sm text-white">{entry.score} pts</div>
                        </div>
                        <div className="min-w-[65px]">
                          <div className="text-[9px] text-neutral-400 uppercase font-semibold">Tiempo</div>
                          <div className="font-mono font-black text-sm text-neutral-200">
                            {formatSpeedrunTime(entry.timeSeconds)}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          {activeTab === 'comparison' && (
            <div className="space-y-6">
              {/* Category Scores Cards (Colores, Estructura, Símbolos) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
                    <Palette className="w-3.5 h-3.5 text-amber-400" />
                    <span>Colores</span>
                  </div>
                  <div className="text-xl font-bold">{result.categoryScores.colors}%</div>
                  <div className="w-full bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-amber-400 h-full rounded-full transition-all"
                      style={{ width: `${result.categoryScores.colors}%` }}
                    />
                  </div>
                </div>

                <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
                    <Shapes className="w-3.5 h-3.5 text-blue-400" />
                    <span>Estructura</span>
                  </div>
                  <div className="text-xl font-bold">{result.categoryScores.structure}%</div>
                  <div className="w-full bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-blue-400 h-full rounded-full transition-all"
                      style={{ width: `${result.categoryScores.structure}%` }}
                    />
                  </div>
                </div>

                <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Símbolos</span>
                  </div>
                  <div className="text-xl font-bold">{result.categoryScores.symbols}%</div>
                  <div className="w-full bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full rounded-full transition-all"
                      style={{ width: `${result.categoryScores.symbols}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Side-by-Side Flag View & Interactive Slider */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* User Flag */}
                <div className="flex flex-col items-center bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
                    Tu Bandera Dibujada
                  </span>
                  <div
                    className="w-full max-w-sm rounded-lg overflow-hidden border-2 border-neutral-700 bg-white shadow-md flex items-center justify-center"
                    style={{ aspectRatio: `${country.ratioValue}` }}
                  >
                    <img
                      src={result.userImageBase64}
                      alt="Tu bandera dibujada"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>

                {/* Reference Flag */}
                <div className="flex flex-col items-center bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
                    Bandera Oficial de Referencia
                  </span>
                  <div
                    className="w-full max-w-sm rounded-lg overflow-hidden border-2 border-neutral-700 bg-white shadow-md flex items-center justify-center"
                    style={{ aspectRatio: `${country.ratioValue}` }}
                  >
                    <img
                      src={result.referenceImageBase64}
                      alt="Bandera oficial"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              </div>

              {/* Interactive Split-Screen Comparison Slider */}
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                    Deslizador de Comparación Milimétrica:
                  </span>
                  <span className="text-xs text-neutral-400">
                    Arrastra para contrastar diferencias exactas
                  </span>
                </div>

                <div
                  className="relative w-full max-w-lg mx-auto rounded-lg overflow-hidden border-2 border-neutral-700 select-none shadow-lg"
                  style={{ aspectRatio: `${country.ratioValue}` }}
                >
                  {/* Background: Official Flag */}
                  <img
                    src={result.referenceImageBase64}
                    alt="Oficial"
                    className="w-full h-full object-contain block pointer-events-none"
                  />

                  {/* Foreground clipped: User Flag */}
                  <div
                    className="absolute inset-0 overflow-hidden pointer-events-none border-r-2 border-amber-400"
                    style={{ width: `${sliderPos}%` }}
                  >
                    <img
                      src={result.userImageBase64}
                      alt="Tu dibujo"
                      className="absolute top-0 left-0 max-w-none h-full"
                      style={{ width: '100%', objectFit: 'contain' }}
                    />
                  </div>

                  {/* Range Slider Control */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sliderPos}
                    onChange={(e) => setSliderPos(Number(e.target.value))}
                    className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full"
                  />

                  {/* Labels on sides */}
                  <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-xs text-[10px] font-bold px-2 py-0.5 rounded text-amber-400 pointer-events-none">
                    TÚ ({sliderPos}%)
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-xs text-[10px] font-bold px-2 py-0.5 rounded text-white pointer-events-none">
                    OFICIAL ({100 - sliderPos}%)
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Details & Feedback Tab */}
          {activeTab === 'details' && (
            <div className="space-y-3">
              <div className="text-xs text-neutral-400 mb-2">
                El evaluador analizó tu dibujo reconociendo la estructura, símbolos y tonos de color:
              </div>

              {result.feedbackItems.map((item, idx) => (
                <div
                  key={idx}
                  className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
                    item.type === 'success'
                      ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-200'
                      : item.type === 'warning'
                      ? 'bg-amber-950/30 border-amber-800/60 text-amber-200'
                      : 'bg-red-950/30 border-red-800/60 text-red-200'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {item.type === 'success' ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : item.type === 'warning' ? (
                      <AlertTriangle className="w-5 h-5 text-amber-400" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-sm text-white">{item.title}</span>
                      <span
                        className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                          item.pointsChange > 0
                            ? 'bg-emerald-900/60 text-emerald-300'
                            : 'bg-red-900/60 text-red-300'
                        }`}
                      >
                        {item.pointsChange > 0 ? `+${item.pointsChange}` : `${item.pointsChange}`} pts
                      </span>
                    </div>
                    <p className="text-xs mt-1 text-neutral-300 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Flag Info & History Tab */}
          {activeTab === 'flagInfo' && (
            <div className="space-y-4 text-sm text-neutral-300">
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                <h4 className="font-bold text-white mb-2">Descripción Oficial</h4>
                <p className="text-xs leading-relaxed text-neutral-400">{country.description}</p>
              </div>

              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                <h4 className="font-bold text-white mb-3">Colores Oficiales Reconocidos</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {country.officialColors.map((c, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 rounded-lg bg-neutral-900 border border-neutral-800">
                      <div
                        className="w-6 h-6 rounded-md border border-neutral-600 shrink-0"
                        style={{ backgroundColor: c.hex }}
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-xs text-white truncate">{c.name}</div>
                        <div className="text-[11px] font-mono text-neutral-400">{c.hex} {c.role ? `• ${c.role}` : ''}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {country.symbols.length > 0 && (
                <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                  <h4 className="font-bold text-white mb-2">Símbolos Requeridos</h4>
                  <ul className="space-y-1 text-xs text-neutral-400">
                    {country.symbols.map((s, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                        <span>{s.name} ({s.type})</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 border-t border-neutral-800 bg-neutral-950/80 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>{copied ? '¡Copiado!' : 'Compartir'}</span>
          </button>

          <div className="flex items-center gap-2 ml-auto flex-wrap">
            {isSpeedrun ? (
              <>
                {onSpeedrunRetry && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onSpeedrunRetry();
                    }}
                    className="px-4 py-2.5 rounded-xl border border-amber-500/40 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs sm:text-sm font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Timer className="w-4 h-4 text-amber-400" />
                    <span>Reintentar Speedrun</span>
                  </button>
                )}

                {onOpenSpeedrunPicker && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onOpenSpeedrunPicker();
                    }}
                    className="px-4 py-2.5 rounded-xl border border-neutral-700 hover:bg-neutral-800 text-neutral-200 text-xs sm:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span>Elegir Otra Bandera</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onNext();
                  }}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs sm:text-sm font-black transition-all shadow-lg hover:shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Siguiente Bandera</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onRetry(true);
                  }}
                  className="px-4 py-2.5 rounded-lg border border-neutral-700 hover:bg-neutral-800 text-neutral-200 text-xs sm:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Corregir mi dibujo</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onNext();
                  }}
                  className="px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs sm:text-sm font-bold transition-all shadow-lg hover:shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Siguiente Bandera</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
