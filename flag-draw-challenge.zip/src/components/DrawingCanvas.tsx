import React, { useRef, useState, useEffect, useCallback } from 'react';
import { ToolType, CountryFlag, GameMode } from '../types';
import {
  Paintbrush,
  Eraser,
  PaintBucket,
  Minus,
  Square,
  Circle,
  Star,
  Undo2,
  Redo2,
  RotateCcw,
  Grid,
  Pipette,
  Lightbulb,
  AlertCircle,
  Home,
  Timer,
  Trophy,
  Zap,
} from 'lucide-react';
import { hexToRgb, rgbDistance } from '../utils/colorUtils';
import { playClickSound } from '../utils/audio';
import { formatSpeedrunTime, getCountryBestRecord } from '../utils/speedrun';
import { getCountryFlagEmoji } from '../utils/emojiUtils';

interface DrawingCanvasProps {
  country: CountryFlag;
  mode?: GameMode;
  onCanvasReady: (canvas: HTMLCanvasElement) => void;
  isEvaluating: boolean;
  onSubmit: (hintsUsed: number, elapsedTimeSeconds: number) => void;
  onOpenMenu: () => void;
  onOpenSpeedrunLeaderboard?: () => void;
  onSelectSpeedrunFlag?: () => void;
  onOpenSpeedrunPicker?: () => void;
}

// 24-color comprehensive heraldic and vexillological world palette
const WORLD_PALETTE = [
  '#FFFFFF', // Blanco
  '#000000', // Negro
  '#71717A', // Gris neutro
  '#D4AF37', // Oro heráldico
  '#C8102E', // Rojo carmesí
  '#DA291C', // Rojo vivo
  '#AA151B', // Rojo español
  '#800020', // Borgoña / Granate
  '#FF671F', // Naranja azafrán
  '#F77F00', // Naranja vivo
  '#FFD100', // Amarillo oro
  '#FFE600', // Amarillo limón
  '#009A44', // Verde esmeralda
  '#006A4E', // Verde panárabe / bosque
  '#228B22', // Verde hierba
  '#00A877', // Verde menta
  '#00205B', // Azul marino oscuro
  '#003399', // Azul real / UE
  '#0055A5', // Azul cobalto
  '#0080FF', // Azul vivo
  '#00A1DE', // Azul celeste
  '#75AADB', // Azul cielo
  '#582C83', // Púrpura heráldico
  '#8B4513', // Marrón
];

// Expanded brush thicknesses including much larger sizes (up to 140px)
const BRUSH_SIZES = [4, 8, 16, 28, 48, 72, 100, 140];

export const DrawingCanvas: React.FC<DrawingCanvasProps> = ({
  country,
  mode,
  onCanvasReady,
  isEvaluating,
  onSubmit,
  onOpenMenu,
  onOpenSpeedrunLeaderboard,
  onSelectSpeedrunFlag,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Speedrun Timer State
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const timerStartRef = useRef<number>(Date.now());
  const timerIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (mode === 'speedrun' && !isEvaluating) {
      timerStartRef.current = Date.now();
      setElapsedTime(0);
      timerIntervalRef.current = window.setInterval(() => {
        setElapsedTime((Date.now() - timerStartRef.current) / 1000);
      }, 30);
      return () => {
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      };
    }
  }, [country.id, mode, isEvaluating]);

  const topRecord = mode === 'speedrun' ? getCountryBestRecord(country.id, country.name) : null;

  // Drawing state
  const [selectedTool, setSelectedTool] = useState<ToolType>('brush');
  const [brushSize, setBrushSize] = useState<number>(28);
  const [currentColor, setCurrentColor] = useState<string>('#DA291C');
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [isEyedropper, setIsEyedropper] = useState<boolean>(false);

  // Hints system (-10% penalty per hint)
  const [hintsUsed, setHintsUsed] = useState<number>(0);
  const [revealedHints, setRevealedHints] = useState<string[]>([]);

  // Undo / Redo history
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyStep, setHistoryStep] = useState<number>(-1);

  // Mouse / Pointer drag state
  const isDrawing = useRef<boolean>(false);
  const startPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const snapshotBeforeShape = useRef<ImageData | null>(null);

  // Dimensions of canvas buffer (high resolution for precision)
  const CANVAS_WIDTH = 960;
  const CANVAS_HEIGHT = Math.round(960 / country.ratioValue);

  // Initialize canvas
  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    // Fill with default white background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Initial snapshot
    const initialData = ctx.getImageData(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    setHistory([initialData]);
    setHistoryStep(0);
    setHintsUsed(0);
    setRevealedHints([]);
    onCanvasReady(canvas);
  }, [CANVAS_WIDTH, CANVAS_HEIGHT, onCanvasReady]);

  useEffect(() => {
    initCanvas();
  }, [country, initCanvas]);

  // Request progressive hint
  const handleRequestHint = () => {
    playClickSound();
    if (hintsUsed >= 3) return;

    const nextCount = hintsUsed + 1;
    let hintText = '';

    if (nextCount === 1) {
      hintText = `🎨 Colores presentes: ${country.officialColors.map((c) => c.name).join(', ')}`;
    } else if (nextCount === 2) {
      if (country.structure.type === 'horizontal_stripes') {
        hintText = `📐 Estructura: ${country.structure.stripeCount || 3} franjas horizontales`;
      } else if (country.structure.type === 'vertical_stripes') {
        hintText = `📐 Estructura: ${country.structure.stripeCount || 3} franjas verticales`;
      } else if (country.structure.type === 'cross') {
        hintText = `📐 Estructura: Diseño en cruz (cruz nórdica o centrada)`;
      } else if (country.structure.type === 'triangle_hoist') {
        hintText = `📐 Estructura: Franjas con triángulo en el asta (lado izquierdo)`;
      } else {
        hintText = `📐 Estructura: ${country.description.split('.')[0]}`;
      }
    } else if (nextCount === 3) {
      if (country.symbols.length > 0) {
        hintText = `⭐ Símbolos: ${country.symbols.map((s) => s.name).join(' • ')}`;
      } else {
        hintText = `⭐ Símbolos: Esta bandera NO contiene escudos ni estrellas (diseño limpio)`;
      }
    }

    setHintsUsed(nextCount);
    setRevealedHints((prev) => [...prev, hintText]);
  };

  // Push state to undo stack
  const saveSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    const nextStep = historyStep + 1;
    const newHistory = history.slice(0, nextStep);
    const snap = ctx.getImageData(0, 0, canvas.width, canvas.height);
    newHistory.push(snap);
    if (newHistory.length > 25) {
      newHistory.shift();
    }
    setHistory(newHistory);
    setHistoryStep(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (historyStep > 0) {
      playClickSound();
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;
      const prevStep = historyStep - 1;
      ctx.putImageData(history[prevStep], 0, 0);
      setHistoryStep(prevStep);
    }
  };

  const handleRedo = () => {
    if (historyStep < history.length - 1) {
      playClickSound();
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;
      const nextStep = historyStep + 1;
      ctx.putImageData(history[nextStep], 0, 0);
      setHistoryStep(nextStep);
    }
  };

  const handleClear = () => {
    playClickSound();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    saveSnapshot();
  };

  // Convert client viewport coordinates to canvas buffer coordinates
  const getCanvasCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  // BFS Flood Fill Algorithm for Bucket Fill Tool
  const floodFill = (startX: number, startY: number, fillHex: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const imgData = ctx.getImageData(0, 0, width, height);
    const data = imgData.data;

    const startIdx = (Math.floor(startY) * width + Math.floor(startX)) * 4;
    const targetR = data[startIdx];
    const targetG = data[startIdx + 1];
    const targetB = data[startIdx + 2];

    const fillRgb = hexToRgb(fillHex);
    if (rgbDistance(targetR, targetG, targetB, fillRgb.r, fillRgb.g, fillRgb.b) < 5) {
      return;
    }

    const queue: [number, number][] = [[Math.floor(startX), Math.floor(startY)]];
    const visited = new Uint8Array(width * height);
    const tolerance = 28;

    while (queue.length > 0) {
      const [cx, cy] = queue.pop()!;
      if (cx < 0 || cx >= width || cy < 0 || cy >= height) continue;

      const pos = cy * width + cx;
      if (visited[pos]) continue;
      visited[pos] = 1;

      const idx = pos * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      if (rgbDistance(r, g, b, targetR, targetG, targetB) <= tolerance) {
        data[idx] = fillRgb.r;
        data[idx + 1] = fillRgb.g;
        data[idx + 2] = fillRgb.b;
        data[idx + 3] = 255;

        queue.push([cx + 1, cy]);
        queue.push([cx - 1, cy]);
        queue.push([cx, cy + 1]);
        queue.push([cx, cy - 1]);
      }
    }

    ctx.putImageData(imgData, 0, 0);
    saveSnapshot();
  };

  // Draw 5-pointed star helper
  const drawStar = (
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    spikes: number,
    outerRadius: number,
    innerRadius: number
  ) => {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fill();
  };

  // Pointer event handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const { x, y } = getCanvasCoords(e);

    // Eyedropper mode
    if (isEyedropper) {
      const pixel = ctx.getImageData(Math.floor(x), Math.floor(y), 1, 1).data;
      const toHex = (n: number) => n.toString(16).padStart(2, '0');
      const hex = `#${toHex(pixel[0])}${toHex(pixel[1])}${toHex(pixel[2])}`.toUpperCase();
      setCurrentColor(hex);
      setIsEyedropper(false);
      return;
    }

    if (selectedTool === 'fill') {
      floodFill(x, y, currentColor);
      return;
    }

    isDrawing.current = true;
    startPos.current = { x, y };
    snapshotBeforeShape.current = ctx.getImageData(0, 0, canvas.width, canvas.height);

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (selectedTool === 'brush') {
      ctx.strokeStyle = currentColor;
      ctx.fillStyle = currentColor;
      ctx.lineWidth = brushSize;
      ctx.beginPath();
      ctx.arc(x, y, brushSize / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (selectedTool === 'eraser') {
      ctx.strokeStyle = '#FFFFFF';
      ctx.fillStyle = '#FFFFFF';
      ctx.lineWidth = brushSize * 1.5;
      ctx.beginPath();
      ctx.arc(x, y, (brushSize * 1.5) / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const { x, y } = getCanvasCoords(e);

    if (selectedTool === 'brush' || selectedTool === 'eraser') {
      ctx.lineTo(x, y);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (snapshotBeforeShape.current) {
      ctx.putImageData(snapshotBeforeShape.current, 0, 0);
      ctx.fillStyle = currentColor;
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = brushSize;

      const sx = startPos.current.x;
      const sy = startPos.current.y;

      if (selectedTool === 'line') {
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(x, y);
        ctx.stroke();
      } else if (selectedTool === 'rect') {
        const rx = Math.min(sx, x);
        const ry = Math.min(sy, y);
        const rw = Math.abs(x - sx);
        const rh = Math.abs(y - sy);
        ctx.fillRect(rx, ry, rw, rh);
      } else if (selectedTool === 'circle') {
        const rx = (x - sx) / 2;
        const ry = (y - sy) / 2;
        const cx = sx + rx;
        const cy = sy + ry;
        ctx.beginPath();
        ctx.ellipse(cx, cy, Math.abs(rx), Math.abs(ry), 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (selectedTool === 'star') {
        const radius = Math.sqrt((x - sx) * (x - sx) + (y - sy) * (y - sy));
        drawStar(ctx, sx, sy, 5, radius, radius * 0.45);
      }
    }
  };

  const handlePointerUp = () => {
    if (isDrawing.current) {
      isDrawing.current = false;
      saveSnapshot();
    }
  };

  return (
    <div className="flex flex-col h-full w-full select-none" id="drawing-workspace">
      {/* Top Toolbar: Tools, Brush Sizes, Grid, Undo/Redo & Hint Button */}
      <div
        className="flex flex-wrap items-center justify-between gap-2 p-2 sm:p-2.5 bg-neutral-900 text-neutral-100 border-b border-neutral-800"
        id="toolbar-top"
      >
        {/* Menu & Drawing Tools */}
        <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
          <button
            type="button"
            title="Volver al Menú Principal"
            onClick={() => {
              playClickSound();
              onOpenMenu();
            }}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors flex items-center gap-1 text-xs font-semibold"
          >
            <Home className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Menú</span>
          </button>

          <div className="h-5 w-px bg-neutral-700 mx-1 hidden sm:block" />

          <button
            id="tool-brush"
            type="button"
            title="Pincel"
            onClick={() => {
              playClickSound();
              setSelectedTool('brush');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'brush'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Paintbrush className="w-4 h-4" />
            <span className="hidden sm:inline">Pincel</span>
          </button>

          <button
            id="tool-eraser"
            type="button"
            title="Goma de borrar"
            onClick={() => {
              playClickSound();
              setSelectedTool('eraser');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'eraser'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Eraser className="w-4 h-4" />
            <span className="hidden sm:inline">Goma</span>
          </button>

          <button
            id="tool-fill"
            type="button"
            title="Bote de relleno"
            onClick={() => {
              playClickSound();
              setSelectedTool('fill');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'fill'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <PaintBucket className="w-4 h-4" />
            <span className="hidden sm:inline">Relleno</span>
          </button>

          {/* Shapes */}
          <button
            id="tool-rect"
            type="button"
            title="Rectángulo (para franjas y cantones)"
            onClick={() => {
              playClickSound();
              setSelectedTool('rect');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'rect'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Square className="w-4 h-4" />
            <span className="hidden md:inline">Rectángulo</span>
          </button>

          <button
            id="tool-line"
            type="button"
            title="Línea recta"
            onClick={() => {
              playClickSound();
              setSelectedTool('line');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'line'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Minus className="w-4 h-4" />
            <span className="hidden md:inline">Línea</span>
          </button>

          <button
            id="tool-circle"
            type="button"
            title="Círculo"
            onClick={() => {
              playClickSound();
              setSelectedTool('circle');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'circle'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Circle className="w-4 h-4" />
            <span className="hidden md:inline">Círculo</span>
          </button>

          <button
            id="tool-star"
            type="button"
            title="Estrella de 5 puntas"
            onClick={() => {
              playClickSound();
              setSelectedTool('star');
            }}
            className={`p-2 rounded-lg flex items-center gap-1 text-xs sm:text-sm font-medium transition-colors ${
              selectedTool === 'star'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-semibold'
                : 'hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Star className="w-4 h-4" />
            <span className="hidden md:inline">Estrella</span>
          </button>
        </div>

        {/* Brush Sizes (Expanded with larger options up to 140px) */}
        <div className="flex items-center gap-1.5 bg-neutral-800/90 px-2 py-1 rounded-xl">
          <span className="text-[11px] text-neutral-400 font-semibold uppercase hidden lg:inline">
            Grosor:
          </span>
          {BRUSH_SIZES.map((size) => (
            <button
              key={size}
              type="button"
              title={`Grosor ${size}px`}
              onClick={() => {
                playClickSound();
                setBrushSize(size);
              }}
              className={`px-1.5 py-0.5 rounded text-[11px] font-bold font-mono transition-all ${
                brushSize === size
                  ? 'bg-amber-500 text-neutral-950 scale-110 shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-700'
              }`}
            >
              {size}
            </button>
          ))}
        </div>

        {/* Hints, Grid & History Actions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Progressive Hint Request Button (-10% penalty per hint) */}
          <button
            type="button"
            onClick={handleRequestHint}
            disabled={hintsUsed >= 3}
            title={
              hintsUsed >= 3
                ? 'Ya has usado las 3 pistas disponibles'
                : `Pedir pista (${3 - hintsUsed} restantes). Te descontará -10% de tu nota final.`
            }
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all border ${
              hintsUsed > 0
                ? 'bg-amber-950/60 border-amber-600 text-amber-300'
                : 'bg-neutral-800 hover:bg-amber-900/40 border-neutral-700 hover:border-amber-500 text-neutral-200'
            } disabled:opacity-40 disabled:cursor-not-allowed`}
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            <span>Pista</span>
            {hintsUsed > 0 && (
              <span className="text-[10px] bg-red-950 text-red-400 px-1 rounded border border-red-800">
                -{hintsUsed * 10}%
              </span>
            )}
          </button>

          {/* Reference Grid */}
          <button
            id="toggle-grid"
            type="button"
            title="Rejilla de referencia (1/2, 1/3, 1/4)"
            onClick={() => {
              playClickSound();
              setShowGrid(!showGrid);
            }}
            className={`p-1.5 sm:p-2 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors ${
              showGrid ? 'bg-amber-500 text-neutral-950' : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
            }`}
          >
            <Grid className="w-4 h-4" />
          </button>

          {/* History Controls */}
          <div className="flex items-center gap-0.5 bg-neutral-800/90 p-1 rounded-lg">
            <button
              id="btn-undo"
              type="button"
              title="Deshacer (Ctrl+Z)"
              disabled={historyStep <= 0}
              onClick={handleUndo}
              className="p-1 rounded hover:bg-neutral-700 disabled:opacity-30 text-neutral-200 transition-opacity"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              id="btn-redo"
              type="button"
              title="Rehacer (Ctrl+Y)"
              disabled={historyStep >= history.length - 1}
              onClick={handleRedo}
              className="p-1 rounded hover:bg-neutral-700 disabled:opacity-30 text-neutral-200 transition-opacity"
            >
              <Redo2 className="w-4 h-4" />
            </button>
            <button
              id="btn-clear"
              type="button"
              title="Limpiar lienzo por completo"
              onClick={handleClear}
              className="p-1 rounded hover:bg-red-900/60 text-red-300 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Speedrun Mode Live Sports Stopwatch & Quick Controls */}
          {mode === 'speedrun' && (
            <div className="flex items-center gap-2 bg-amber-500/15 border border-amber-500/40 px-2.5 py-1 rounded-xl shadow-inner">
              <Timer className="w-4 h-4 text-amber-400 animate-pulse" />
              <span className="font-mono font-black text-xs sm:text-sm text-amber-400">
                {formatSpeedrunTime(elapsedTime)}
              </span>
              {topRecord && (
                <span className="hidden xl:inline text-[11px] text-neutral-400 border-l border-amber-500/30 pl-2">
                  1º: <strong className="text-amber-300">{topRecord.score} pts</strong> ({formatSpeedrunTime(topRecord.timeSeconds)})
                </span>
              )}
              {onOpenSpeedrunLeaderboard && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onOpenSpeedrunLeaderboard();
                  }}
                  title="Ver clasificación de esta bandera"
                  className="px-2 py-0.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Trophy className="w-3 h-3 text-amber-400" />
                  <span className="hidden sm:inline">Récords</span>
                </button>
              )}
              {onSelectSpeedrunFlag && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onSelectSpeedrunFlag();
                  }}
                  title="Elegir otra bandera para speedrun"
                  className="px-2 py-0.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Zap className="w-3 h-3 text-amber-400" />
                  <span className="hidden sm:inline">Elegir Bandera</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Revealed Hints Alert Banner (if player requested hints) */}
      {revealedHints.length > 0 && (
        <div className="bg-amber-950/40 border-b border-amber-800/50 px-3 py-1.5 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 overflow-x-auto text-amber-200">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <div className="flex items-center gap-3">
              {revealedHints.map((hint, idx) => (
                <span key={idx} className="font-medium">
                  {hint}
                </span>
              ))}
            </div>
          </div>
          <span className="text-[11px] font-bold text-red-400 shrink-0 bg-red-950/70 border border-red-800/70 px-2 py-0.5 rounded">
            Penalización aplicada: -{hintsUsed * 10}%
          </span>
        </div>
      )}

      {/* Full 24-Color Spectrum Palette Bar (No official colors revealed!) */}
      <div
        className="flex items-center justify-between gap-2 px-3 py-2 bg-neutral-950 border-b border-neutral-800 flex-wrap"
        id="color-palette-bar"
      >
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs text-neutral-400 font-semibold mr-1">Paleta de Colores:</span>
          {WORLD_PALETTE.map((hex) => (
            <button
              key={hex}
              type="button"
              title={hex}
              onClick={() => {
                playClickSound();
                setCurrentColor(hex);
              }}
              className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full border transition-all ${
                currentColor.toUpperCase() === hex.toUpperCase()
                  ? 'ring-2 ring-amber-400 scale-125 z-10 border-white shadow-md'
                  : 'border-neutral-700 hover:scale-110'
              }`}
              style={{ backgroundColor: hex }}
            />
          ))}
        </div>

        {/* Custom Hex & Eyedropper */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            id="tool-eyedropper"
            type="button"
            title="Cuentagotas (copiar color del lienzo)"
            onClick={() => {
              playClickSound();
              setIsEyedropper(!isEyedropper);
            }}
            className={`p-1.5 rounded-md text-xs transition-colors ${
              isEyedropper ? 'bg-amber-400 text-neutral-950' : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
            }`}
          >
            <Pipette className="w-3.5 h-3.5" />
          </button>

          <label className="flex items-center gap-1.5 cursor-pointer bg-neutral-800 px-2.5 py-1 rounded-lg hover:bg-neutral-700 border border-neutral-700">
            <span className="w-4 h-4 rounded-full border border-neutral-600" style={{ backgroundColor: currentColor }} />
            <span className="text-[11px] font-mono text-neutral-200">{currentColor}</span>
            <input
              type="color"
              value={currentColor}
              onChange={(e) => setCurrentColor(e.target.value.toUpperCase())}
              className="sr-only"
            />
          </label>
        </div>
      </div>

      {/* Main Canvas Workspace Area */}
      <div
        ref={containerRef}
        className="flex-1 bg-neutral-950 relative flex items-center justify-center p-2 sm:p-4 overflow-hidden"
        id="canvas-stage"
      >
        {/* Canvas Frame honoring exact country aspect ratio */}
        <div
          className="relative max-w-full max-h-full flex items-center justify-center shadow-2xl rounded-sm overflow-hidden border-2 border-neutral-700 bg-white"
          style={{
            aspectRatio: `${country.ratioValue}`,
            width: `min(100%, calc(76vh * ${country.ratioValue}))`,
          }}
        >
          {/* The Drawing Canvas */}
          <canvas
            ref={canvasRef}
            id="flag-canvas"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
            className="w-full h-full block cursor-crosshair touch-none"
            style={{ imageRendering: 'auto' }}
          />

          {/* Optional Reference Grid Overlay */}
          {showGrid && (
            <div className="absolute inset-0 pointer-events-none grid grid-cols-6 grid-rows-6 border border-amber-400/40">
              {Array.from({ length: 36 }).map((_, i) => (
                <div key={i} className="border border-amber-400/20" />
              ))}
              <div className="absolute top-1/2 left-0 right-0 border-t border-dashed border-red-500/60" />
              <div className="absolute left-1/2 top-0 bottom-0 border-l border-dashed border-red-500/60" />
              <div className="absolute top-1/3 left-0 right-0 border-t border-dotted border-blue-500/60" />
              <div className="absolute top-2/3 left-0 right-0 border-t border-dotted border-blue-500/60" />
              <div className="absolute left-1/3 top-0 bottom-0 border-l border-dotted border-blue-500/60" />
              <div className="absolute left-2/3 top-0 bottom-0 border-l border-dotted border-blue-500/60" />
            </div>
          )}
        </div>
      </div>

      {/* Bottom Action Footer */}
      <div
        className="flex items-center justify-between p-2.5 sm:p-3 bg-neutral-900 border-t border-neutral-800 text-neutral-300 text-xs sm:text-sm"
        id="drawing-footer"
      >
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-neutral-400">País:</span>
            <span className="text-white font-bold text-sm">
              {country.name}
            </span>
          </div>
          {mode === 'speedrun' ? (
            <span className="hidden sm:inline text-amber-400 font-semibold text-xs flex items-center gap-1">
              <Zap className="w-3 h-3 fill-current" />
              <span>Speedrun: Gana mayor nota; desempate por menor tiempo</span>
            </span>
          ) : (
            <span className="hidden md:inline text-neutral-400 text-xs">
              (Puntuación mínima para racha y completado: 90 pts)
            </span>
          )}
        </div>

        <button
          id="btn-submit-drawing"
          type="button"
          disabled={isEvaluating}
          onClick={() => {
            playClickSound();
            const finalTime = mode === 'speedrun' ? (Date.now() - timerStartRef.current) / 1000 : 0;
            onSubmit(hintsUsed, finalTime);
          }}
          className="bg-amber-500 hover:bg-amber-400 disabled:bg-neutral-700 text-neutral-950 font-black px-6 sm:px-9 py-2.5 rounded-xl shadow-lg hover:shadow-amber-500/20 transition-all flex items-center gap-2 text-sm sm:text-base cursor-pointer"
        >
          {isEvaluating ? (
            <>
              <div className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
              <span>Analizando bandera...</span>
            </>
          ) : mode === 'speedrun' ? (
            <>
              <Timer className="w-4 h-4" />
              <span>Finalizar Carrera ({formatSpeedrunTime(elapsedTime)})</span>
              <span className="text-xs bg-neutral-950/20 px-1.5 py-0.5 rounded font-bold">Enter ↵</span>
            </>
          ) : (
            <>
              <span>Enviar a Corrección</span>
              <span className="text-xs bg-neutral-950/20 px-1.5 py-0.5 rounded font-bold">Enter ↵</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
