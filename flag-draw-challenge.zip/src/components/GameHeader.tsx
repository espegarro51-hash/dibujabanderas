import React from 'react';
import { CountryFlag, GameMode, GameStats } from '../types';
import {
  Globe,
  Flame,
  Trophy,
  Dices,
  Volume2,
  VolumeX,
  Compass,
  Zap,
} from 'lucide-react';
import { playClickSound } from '../utils/audio';
import { getCountryFlagEmoji } from '../utils/emojiUtils';

interface GameHeaderProps {
  currentCountry: CountryFlag;
  mode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  stats: GameStats;
  onOpenAtlas: () => void;
  onNextRandom: () => void;
  onOpenMenu: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const GameHeader: React.FC<GameHeaderProps> = ({
  currentCountry,
  mode,
  onSelectMode,
  stats,
  onOpenAtlas,
  onNextRandom,
  onOpenMenu,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="bg-neutral-900 border-b border-neutral-800 text-neutral-100" id="game-header">
      {/* Top Banner: Brand, Stats & Quick Actions */}
      <div className="px-4 py-2.5 flex items-center justify-between gap-3 border-b border-neutral-800/80">
        {/* Brand with Click to Open Menu */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            onOpenMenu();
          }}
          className="flex items-center gap-2.5 hover:opacity-85 transition-opacity text-left cursor-pointer"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-red-500 flex items-center justify-center shadow-md shadow-amber-500/10">
            <Compass className="w-5 h-5 text-neutral-950 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-1.5 leading-none">
              <span className="text-white">Flag Draw</span>
              <span className="text-amber-400">Challenge</span>
            </h1>
            <span className="text-[10px] text-neutral-400 font-medium hidden sm:inline">
              Menú Principal & Estadísticas
            </span>
          </div>
        </button>

        {/* Player Stats HUD */}
        <div className="flex items-center gap-3 sm:gap-5 text-xs font-semibold">
          {/* Streak (min 90 pts) */}
          <div
            className="flex items-center gap-1 text-orange-400 bg-orange-950/40 px-2.5 py-1 rounded-full border border-orange-800/50"
            title="Racha de banderas superadas (mínimo 90 pts requeridos)"
          >
            <Flame className="w-4 h-4 fill-current" />
            <span>{stats.currentStreak}</span>
            <span className="hidden sm:inline text-[10px] text-orange-300 font-normal">racha (≥90)</span>
          </div>

          {/* Mastered Flags Count (>= 90 pts) */}
          <div
            className="flex items-center gap-1 text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-full border border-emerald-800/50"
            title="Banderas superadas con nota ≥ 90"
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>{stats.flagsCompleted}</span>
            <span className="hidden sm:inline text-[10px] text-emerald-300 font-normal">completadas</span>
          </div>

          {/* Audio toggle */}
          <button
            type="button"
            onClick={onToggleSound}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            title={soundEnabled ? 'Silenciar sonidos' : 'Activar sonidos'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Atlas button */}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onOpenAtlas();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-medium transition-colors border border-neutral-700 text-xs cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>Atlas ({Object.keys(stats.completedFlags).length})</span>
          </button>
        </div>
      </div>

      {/* Target Challenge Prompt Bar */}
      <div className="px-4 py-3 bg-neutral-950 flex flex-wrap items-center justify-between gap-4">
        {/* Country Name Prompt */}
        <div className="flex items-center gap-3">
          {mode === 'speedrun' ? (
            <span className="text-xs uppercase tracking-wider font-black text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded-md flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>SPEEDRUN:</span>
            </span>
          ) : (
            <span className="text-xs uppercase tracking-wider font-bold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-2.5 py-1 rounded-md">
              Dibuja la bandera de:
            </span>
          )}
          <div className="flex items-center gap-2">
            <span className="text-xl sm:text-2xl font-black text-white tracking-wide">
              {currentCountry.name}
            </span>
            <span className="text-xl">{getCountryFlagEmoji(currentCountry.id)}</span>
            <span className="text-xs text-neutral-400 font-medium">
              ({currentCountry.continent})
            </span>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Random Next Flag button */}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onNextRandom();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white text-xs font-semibold border border-neutral-700 transition-colors"
            title="Cambiar a otra bandera al azar"
          >
            <Dices className="w-4 h-4 text-amber-400" />
            <span>Otra bandera</span>
          </button>
        </div>
      </div>
    </header>
  );
};
