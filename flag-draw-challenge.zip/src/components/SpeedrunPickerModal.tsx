import React, { useState, useMemo } from 'react';
import { CountryFlag, Continent } from '../types';
import { ALL_COUNTRIES } from '../data/countries';
import { getCountryFlagEmoji } from '../utils/emojiUtils';
import { getCountryBestRecord, formatSpeedrunTime } from '../utils/speedrun';
import { Search, X, Zap, Trophy, Dices, Timer } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface SpeedrunPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCountry: (country: CountryFlag) => void;
  currentCountryId?: string;
  onOpenLeaderboardForCountry?: (country: CountryFlag) => void;
}

const CONTINENTS: (Continent | 'Todos')[] = ['Todos', 'Europa', 'América', 'Asia', 'África', 'Oceanía'];

export const SpeedrunPickerModal: React.FC<SpeedrunPickerModalProps> = ({
  isOpen,
  onClose,
  onSelectCountry,
  currentCountryId,
  onOpenLeaderboardForCountry,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContinent, setSelectedContinent] = useState<Continent | 'Todos'>('Todos');

  const filteredCountries = useMemo(() => {
    return ALL_COUNTRIES.filter((c) => {
      const matchSearch =
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.englishName.toLowerCase().includes(searchTerm.toLowerCase());
      if (!matchSearch) return false;
      if (selectedContinent !== 'Todos' && c.continent !== selectedContinent) return false;
      return true;
    });
  }, [searchTerm, selectedContinent]);

  if (!isOpen) return null;

  const handleRandom = () => {
    playClickSound();
    const rand = ALL_COUNTRIES[Math.floor(Math.random() * ALL_COUNTRIES.length)];
    onSelectCountry(rand);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-neutral-900 border border-neutral-800 w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                <span>Modo Speedrun: Elige tu Bandera</span>
              </h2>
              <p className="text-xs text-neutral-400">
                Selecciona cualquier país del mundo para intentar batir su récord oficial
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRandom}
              className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-neutral-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Dices className="w-4 h-4 text-amber-400" />
              <span>Aleatoria</span>
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="p-4 border-b border-neutral-800 bg-neutral-950/40 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por nombre de país (ej: España, Japón, Brasil, Nepal...)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            {CONTINENTS.map((cont) => (
              <button
                key={cont}
                type="button"
                onClick={() => {
                  playClickSound();
                  setSelectedContinent(cont);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedContinent === cont
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-md'
                    : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 border border-neutral-800'
                }`}
              >
                {cont}
              </button>
            ))}
          </div>
        </div>

        {/* Flag Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredCountries.map((country) => {
            const isCurrent = country.id === currentCountryId;
            const topRecord = getCountryBestRecord(country.id, country.name);

            return (
              <button
                key={country.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  onSelectCountry(country);
                  onClose();
                }}
                className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all group cursor-pointer ${
                  isCurrent
                    ? 'bg-amber-500/10 border-amber-500/60 ring-1 ring-amber-500/30'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-800/40'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-3xl filter drop-shadow-sm group-hover:scale-110 transition-transform">
                    {getCountryFlagEmoji(country.id)}
                  </span>
                  <div>
                    <div className="font-bold text-sm text-white group-hover:text-amber-400 transition-colors flex items-center gap-1.5">
                      <span>{country.name}</span>
                    </div>
                    <div className="text-[11px] text-neutral-400">{country.continent}</div>
                  </div>
                </div>

                {/* Top Record Chip */}
                {topRecord && (
                  <div className="text-right">
                    <div className="flex items-center justify-end gap-1 text-[11px] font-black text-amber-400">
                      <Trophy className="w-3 h-3" />
                      <span>{topRecord.score} pts</span>
                    </div>
                    <div className="flex items-center justify-end gap-1 text-[10px] font-mono text-neutral-400">
                      <Timer className="w-3 h-3" />
                      <span>{formatSpeedrunTime(topRecord.timeSeconds)}</span>
                    </div>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-neutral-800 bg-neutral-950/80 flex items-center justify-between text-xs text-neutral-400">
          <span>
            Mostrando <strong>{filteredCountries.length}</strong> banderas disponibles
          </span>
          <span className="text-amber-400 font-semibold">
            ¡Dibuja rápido y preciso para conquistar el 1º puesto!
          </span>
        </div>
      </div>
    </div>
  );
};
