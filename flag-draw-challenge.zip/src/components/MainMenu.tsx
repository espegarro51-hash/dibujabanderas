import React from 'react';
import { GameMode, GameStats, Continent } from '../types';
import { GoogleUser } from '../utils/auth';
import {
  Compass,
  Play,
  Globe,
  Flame,
  Trophy,
  Dices,
  LogOut,
  Sparkles,
  Info,
  ShieldCheck,
  Layers,
  Zap,
  Timer,
} from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface MainMenuProps {
  user: GoogleUser;
  stats: GameStats;
  mode: GameMode;
  onSelectMode: (m: GameMode) => void;
  selectedContinent?: Continent;
  onSelectContinent: (c?: Continent) => void;
  onStartGame: () => void;
  onOpenAtlas: () => void;
  onOpenSpeedrunPicker?: () => void;
  onOpenSpeedrunLeaderboards?: () => void;
  onLogout: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  user,
  stats,
  mode,
  onSelectMode,
  selectedContinent,
  onSelectContinent,
  onStartGame,
  onOpenAtlas,
  onOpenSpeedrunPicker,
  onOpenSpeedrunLeaderboards,
  onLogout,
}) => {
  return (
    <div className="h-full w-full overflow-y-auto bg-neutral-950 text-neutral-100 flex flex-col items-center p-4 sm:p-8 select-none">
      {/* Top Profile & Header Bar */}
      <div className="w-full max-w-4xl flex items-center justify-between pb-6 border-b border-neutral-800/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-red-500 flex items-center justify-center shadow-lg shadow-amber-500/10">
            <Compass className="w-6 h-6 text-neutral-950 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight leading-none">
              Flag Draw <span className="text-amber-400">Challenge</span>
            </h1>
            <span className="text-xs text-neutral-400">El corrector estricto de banderas</span>
          </div>
        </div>

        {/* User Google Badge & Logout */}
        <div className="flex items-center gap-2 sm:gap-3 bg-neutral-900/90 border border-neutral-800 px-3 py-1.5 rounded-2xl">
          <img
            src={user.picture}
            alt={user.name}
            className="w-8 h-8 rounded-full border border-neutral-700 bg-neutral-800 object-cover"
          />
          <div className="text-left hidden sm:block">
            <div className="text-xs font-bold text-white truncate max-w-[120px]">{user.name}</div>
            <div className="text-[10px] text-neutral-400 truncate max-w-[140px] font-mono">{user.email}</div>
          </div>
          <button
            type="button"
            title="Cerrar sesión"
            onClick={() => {
              playClickSound();
              onLogout();
            }}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-neutral-800 transition-colors ml-1"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Center Content */}
      <div className="w-full max-w-4xl flex-1 flex flex-col items-center py-6 sm:py-10 space-y-8">
        {/* Stats Strip */}
        <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col items-center text-center">
            <div className="flex items-center gap-1 text-orange-400 text-xs font-semibold mb-1">
              <Flame className="w-4 h-4 fill-current" />
              <span>Racha Actual</span>
            </div>
            <span className="text-2xl sm:text-3xl font-black text-white">{stats.currentStreak}</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">mínimo 90 pts para sumar</span>
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col items-center text-center">
            <div className="flex items-center gap-1 text-emerald-400 text-xs font-semibold mb-1">
              <Trophy className="w-4 h-4" />
              <span>Completadas</span>
            </div>
            <span className="text-2xl sm:text-3xl font-black text-white">{stats.flagsCompleted}</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">con nota ≥ 90</span>
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col items-center text-center">
            <div className="flex items-center gap-1 text-amber-400 text-xs font-semibold mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Perfectas</span>
            </div>
            <span className="text-2xl sm:text-3xl font-black text-white">{stats.perfectScores}</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">nota 95 - 100 pts</span>
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col items-center text-center">
            <div className="flex items-center gap-1 text-blue-400 text-xs font-semibold mb-1">
              <Layers className="w-4 h-4" />
              <span>Total Dibujadas</span>
            </div>
            <span className="text-2xl sm:text-3xl font-black text-white">{stats.totalDrawn}</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">intentos realizados</span>
          </div>
        </div>

        {/* Big Start Button */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            onStartGame();
          }}
          className="w-full max-w-md py-4 px-8 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950 font-black text-lg sm:text-xl shadow-xl hover:shadow-amber-500/20 hover:scale-102 active:scale-98 transition-all flex items-center justify-center gap-3 cursor-pointer"
        >
          <Play className="w-6 h-6 fill-current" />
          <span>¡JUGAR AHORA!</span>
        </button>

        {/* Game Mode Picker */}
        <div className="w-full space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">
              Modo de Juego
            </h3>
            <span className="text-xs text-neutral-500">Selecciona el tipo de desafío</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {/* Speedrun Mode */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onSelectMode('speedrun');
                onSelectContinent(undefined);
              }}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
                mode === 'speedrun'
                  ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40 text-white shadow-lg shadow-amber-500/10'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-amber-500/40 text-neutral-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Zap className="w-5 h-5 text-amber-400 fill-current" />
                <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded">
                  RÉCORDS
                </span>
              </div>
              <div className="font-bold text-sm text-white">Modo Speedrun</div>
              <div className="text-xs text-neutral-400 mt-1">
                Elige bandera y bate récords. Gana la mayor nota y desempata menor tiempo.
              </div>
            </button>

            {/* Random */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onSelectMode('aleatorio');
                onSelectContinent(undefined);
              }}
              className={`p-4 rounded-2xl border text-left transition-all ${
                mode === 'aleatorio'
                  ? 'bg-amber-950/40 border-amber-500 ring-1 ring-amber-500 text-white'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 text-neutral-300'
              }`}
            >
              <Dices className="w-5 h-5 text-amber-400 mb-2" />
              <div className="font-bold text-sm">Aleatorio Mundial</div>
              <div className="text-xs text-neutral-400 mt-1">Cualquier país del mundo de los 193+ miembros.</div>
            </button>

            {/* Continent */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onSelectMode('continente');
                if (!selectedContinent) onSelectContinent('Europa');
              }}
              className={`p-4 rounded-2xl border text-left transition-all ${
                mode === 'continente'
                  ? 'bg-amber-950/40 border-amber-500 ring-1 ring-amber-500 text-white'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 text-neutral-300'
              }`}
            >
              <Globe className="w-5 h-5 text-blue-400 mb-2" />
              <div className="font-bold text-sm">Por Continente</div>
              <div className="text-xs text-neutral-400 mt-1">Filtra por Europa, América, Asia, África u Oceanía.</div>
            </button>

            {/* Difficult */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onSelectMode('dificiles');
                onSelectContinent(undefined);
              }}
              className={`p-4 rounded-2xl border text-left transition-all ${
                mode === 'dificiles'
                  ? 'bg-amber-950/40 border-amber-500 ring-1 ring-amber-500 text-white'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 text-neutral-300'
              }`}
            >
              <Trophy className="w-5 h-5 text-purple-400 mb-2" />
              <div className="font-bold text-sm">Banderas Difíciles</div>
              <div className="text-xs text-neutral-400 mt-1">Solo banderas de nivel 4 y 5 con dragones, leones y escudos.</div>
            </button>

            {/* Atlas Explorer */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onOpenAtlas();
              }}
              className="p-4 rounded-2xl border border-neutral-800 bg-neutral-900/60 hover:border-amber-400/50 hover:bg-neutral-900 text-left transition-all group cursor-pointer"
            >
              <Globe className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-bold text-sm text-white">Atlas de Banderas</div>
              <div className="text-xs text-neutral-400 mt-1">Explora los países con sus emojis y elige cuál dibujar.</div>
            </button>
          </div>

          {/* Speedrun Mode Quick Actions Bar */}
          {mode === 'speedrun' && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-400/5 to-transparent border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 text-xs text-amber-300">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Criterio oficial:</strong> 1º Mayor nota obtenida · 2º En caso de empate, desempata el menor tiempo.
                </span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                {onOpenSpeedrunPicker && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onOpenSpeedrunPicker();
                    }}
                    className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    <span>Elegir Bandera</span>
                  </button>
                )}
                {onOpenSpeedrunLeaderboards && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onOpenSpeedrunLeaderboards();
                    }}
                    className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Trophy className="w-3.5 h-3.5 text-amber-400" />
                    <span>Ver Clasificaciones</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Continent selector if continent mode chosen */}
          {mode === 'continente' && (
            <div className="flex items-center gap-2 pt-2 overflow-x-auto pb-1">
              {(['Europa', 'América', 'Asia', 'África', 'Oceanía'] as Continent[]).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onSelectContinent(c);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    selectedContinent === c
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 border border-neutral-800'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Challenge Standard & Criteria */}
        <div className="w-full space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Corrección Inteligente
            </h3>
            <span className="text-xs text-neutral-400 font-medium">Evaluación universal de estructura y tonalidades</span>
          </div>

          <div className="bg-gradient-to-r from-amber-950/30 via-neutral-900 to-neutral-900 border border-neutral-800 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-black tracking-wider uppercase">
                  Reconocimiento Avanzado
                </span>
                <span className="text-white font-bold text-sm sm:text-base">
                  Estructura, Franjas y Gama Cromática
                </span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                El analizador examina el orden de las franjas, orientación geométrica, símbolos y la fidelidad tonal de los colores elegidos. Se exige una nota de al menos <strong className="text-amber-400">90 / 100</strong> para aprobar y sumar a tu racha.
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="text-center px-3 py-2 rounded-xl bg-neutral-900/80 border border-neutral-800">
                <div className="text-emerald-400 font-mono font-black text-sm">Smart AI</div>
                <div className="text-[10px] text-neutral-400">Estructura</div>
              </div>
              <div className="text-center px-3 py-2 rounded-xl bg-neutral-900/80 border border-neutral-800">
                <div className="text-amber-400 font-mono font-black text-sm">≥ 90 pts</div>
                <div className="text-[10px] text-neutral-400">Para Racha</div>
              </div>
            </div>
          </div>
        </div>

        {/* Rules Notice */}
        <div className="w-full bg-neutral-900/60 border border-neutral-800 rounded-2xl p-4 text-xs text-neutral-400 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-bold text-white block">Reglas del Desafío:</span>
            <p>
              • <strong>Mínimo 90 puntos</strong> para marcar una bandera como completada y sumar a tu racha de victorias.
            </p>
            <p>
              • <strong>Sin colores oficiales a la vista</strong>: debes recordar o deducir los colores correctos de la bandera.
            </p>
            <p>
              • <strong>Sistema de pistas</strong>: puedes pedir hasta 3 pistas dentro del lienzo, pero cada pista resta <strong>-10%</strong> de tu nota final.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
