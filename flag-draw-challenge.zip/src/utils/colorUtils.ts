/**
 * Color math and perceptual difference utilities for Flag Draw Challenge
 */

export interface RGB {
  r: number;
  g: number;
  b: number;
  a?: number;
}

export interface Lab {
  l: number;
  a: number;
  b: number;
}

export function hexToRgb(hex: string): RGB {
  let clean = hex.replace('#', '').trim();
  if (clean.length === 3) {
    clean = clean
      .split('')
      .map((c) => c + c)
      .join('');
  }
  const num = parseInt(clean, 16);
  if (isNaN(num)) {
    return { r: 0, g: 0, b: 0 };
  }
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

export function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (n: number) => {
    const clamped = Math.max(0, Math.min(255, Math.round(n)));
    return clamped.toString(16).padStart(2, '0');
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}

/**
 * Convert sRGB to CIEXYZ (D65 Illuminant)
 */
export function rgbToXyz(rgb: RGB): { x: number; y: number; z: number } {
  let r = rgb.r / 255;
  let g = rgb.g / 255;
  let b = rgb.b / 255;

  r = r > 0.04045 ? Math.pow((r + 0.055) / 1.055, 2.4) : r / 12.92;
  g = g > 0.04045 ? Math.pow((g + 0.055) / 1.055, 2.4) : g / 12.92;
  b = b > 0.04045 ? Math.pow((b + 0.055) / 1.055, 2.4) : b / 12.92;

  r *= 100;
  g *= 100;
  b *= 100;

  const x = r * 0.4124 + g * 0.3576 + b * 0.1805;
  const y = r * 0.2126 + g * 0.7152 + b * 0.0722;
  const z = r * 0.0193 + g * 0.1192 + b * 0.9505;

  return { x, y, z };
}

/**
 * Convert CIEXYZ to CIELAB
 */
export function xyzToLab(xyz: { x: number; y: number; z: number }): Lab {
  // D65 reference white
  const refX = 95.047;
  const refY = 100.0;
  const refZ = 108.883;

  let x = xyz.x / refX;
  let y = xyz.y / refY;
  let z = xyz.z / refZ;

  x = x > 0.008856 ? Math.pow(x, 1 / 3) : 7.787 * x + 16 / 116;
  y = y > 0.008856 ? Math.pow(y, 1 / 3) : 7.787 * y + 16 / 116;
  z = z > 0.008856 ? Math.pow(z, 1 / 3) : 7.787 * z + 16 / 116;

  return {
    l: 116 * y - 16,
    a: 500 * (x - y),
    b: 200 * (y - z),
  };
}

export function rgbToLab(rgb: RGB): Lab {
  return xyzToLab(rgbToXyz(rgb));
}

export function hexToLab(hex: string): Lab {
  return rgbToLab(hexToRgb(hex));
}

/**
 * CIE94 Delta-E color distance (Perceptually uniform)
 * Returns values where:
 * < 5 : Very close, humanly indistinguishable in casual viewing
 * 5 - 12: Slight variation (acceptable digital tolerance)
 * 12 - 22: Noticeably different shade (e.g. scarlet vs crimson, light navy vs royal)
 * > 22 : Clearly distinct colors (e.g. orange vs red, turquoise vs green, gold vs yellow)
 */
export function deltaE94(lab1: Lab, lab2: Lab): number {
  const dL = lab1.l - lab2.l;
  const c1 = Math.sqrt(lab1.a * lab1.a + lab1.b * lab1.b);
  const c2 = Math.sqrt(lab2.a * lab2.a + lab2.b * lab2.b);
  const dC = c1 - c2;
  const da = lab1.a - lab2.a;
  const db = lab1.b - lab2.b;
  const dH2 = Math.max(0, da * da + db * db - dC * dC);
  const dH = Math.sqrt(dH2);

  const kL = 1;
  const kC = 1;
  const kH = 1;
  const k1 = 0.045;
  const k2 = 0.015;

  const sL = 1;
  const sC = 1 + k1 * c1;
  const sH = 1 + k2 * c1;

  const term1 = dL / (kL * sL);
  const term2 = dC / (kC * sC);
  const term3 = dH / (kH * sH);

  return Math.sqrt(term1 * term1 + term2 * term2 + term3 * term3);
}

/**
 * Fast Euclidean distance between two hex colors in CIELab space
 */
export function colorDifference(hex1: string, hex2: string): number {
  const lab1 = hexToLab(hex1);
  const lab2 = hexToLab(hex2);
  return deltaE94(lab1, lab2);
}

/**
 * RGB distance for quick pixel comparison
 */
export function rgbDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  const dr = r1 - r2;
  const dg = g1 - g2;
  const db = b1 - b2;
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

export function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  const rNorm = r / 255;
  const gNorm = g / 255;
  const bNorm = b / 255;
  const max = Math.max(rNorm, gNorm, bNorm);
  const min = Math.min(rNorm, gNorm, bNorm);
  const l = (max + min) / 2;

  if (max === min) {
    return { h: 0, s: 0, l };
  }

  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

  let h = 0;
  switch (max) {
    case rNorm:
      h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0);
      break;
    case gNorm:
      h = (bNorm - rNorm) / d + 2;
      break;
    case bNorm:
      h = (rNorm - gNorm) / d + 4;
      break;
  }
  h = Math.round(h * 60);

  return { h, s, l };
}

export type ColorFamily =
  | 'red'
  | 'orange'
  | 'yellow'
  | 'green'
  | 'cyan'
  | 'blue'
  | 'purple'
  | 'white'
  | 'black'
  | 'gray'
  | 'brown';

export function getColorFamily(hex: string): ColorFamily {
  const rgb = hexToRgb(hex);
  const { h, s, l } = rgbToHsl(rgb.r, rgb.g, rgb.b);

  // Black / White / Gray based on Lightness & Saturation
  if (l < 0.16) return 'black';
  if (l > 0.85 && s < 0.28) return 'white';
  if (s < 0.18) {
    if (l < 0.22) return 'black';
    if (l > 0.8) return 'white';
    return 'gray';
  }

  // Brown (Dark Orange/Yellow with lower lightness and moderate saturation)
  if (h >= 15 && h <= 45 && l < 0.38 && s > 0.25) {
    return 'brown';
  }

  // Hue classifications
  if (h >= 345 || h < 16) return 'red';
  if (h >= 16 && h < 42) return 'orange';
  if (h >= 42 && h < 68) return 'yellow';
  if (h >= 68 && h < 165) return 'green';
  if (h >= 165 && h < 195) return 'cyan';
  if (h >= 195 && h < 265) return 'blue';
  if (h >= 265 && h < 345) return 'purple';

  return 'gray';
}

/**
 * Intelligent color comparator that recognizes valid tone variations of the same color family
 * (e.g. crimson vs scarlet, cadmium yellow vs gold, cobalt vs navy) while strictly rejecting
 * completely wrong color families or rogue hues.
 */
export function isColorToneMatch(
  userHex: string,
  targetHex: string,
  strictMode: boolean = false
): {
  isMatch: boolean;
  score: number; // 0 to 100
  deltaE: number;
  userFamily: ColorFamily;
  targetFamily: ColorFamily;
  description: string;
} {
  const uRgb = hexToRgb(userHex);
  const tRgb = hexToRgb(targetHex);
  const uLab = rgbToLab(uRgb);
  const tLab = rgbToLab(tRgb);
  const deltaE = deltaE94(uLab, tLab);

  const userFamily = getColorFamily(userHex);
  const targetFamily = getColorFamily(targetHex);

  const uHsl = rgbToHsl(uRgb.r, uRgb.g, uRgb.b);
  const tHsl = rgbToHsl(tRgb.r, tRgb.g, tRgb.b);

  // 1. Exact or near-identical color (Delta-E <= 14.0)
  if (deltaE <= 14.0) {
    return {
      isMatch: true,
      score: 100,
      deltaE,
      userFamily,
      targetFamily,
      description: 'Tono exacto de alta fidelidad',
    };
  }

  // 2. Same color family with acceptable tone variation (e.g. crimson vs scarlet, cobalt vs navy)
  const isSameFamily = userFamily === targetFamily;
  const isAdjacentFamily =
    (userFamily === 'yellow' && targetFamily === 'orange') ||
    (userFamily === 'orange' && targetFamily === 'yellow') ||
    (userFamily === 'cyan' && targetFamily === 'blue') ||
    (userFamily === 'blue' && targetFamily === 'cyan');

  if (isSameFamily) {
    // If both are the same family, check that lightness difference isn't completely extreme (e.g. white vs black)
    const lDiff = Math.abs(uHsl.l - tHsl.l);

    if (deltaE <= 32.0 || lDiff < 0.5) {
      // Recognized as a valid shade/tone of the intended color!
      // Barely penalizes: gives 94-99 score
      const score = Math.max(93, Math.min(99, Math.round(100 - deltaE * 0.2)));
      return {
        isMatch: true,
        score,
        deltaE,
        userFamily,
        targetFamily,
        description: `Tono adecuado de ${describeColorName(userHex).toLowerCase()} reconocido`,
      };
    }
  }

  // 3. Permissible adjacent family with close Delta-E (e.g. golden yellow vs warm amber-orange)
  if (isAdjacentFamily && deltaE <= 24.0) {
    return {
      isMatch: true,
      score: 90,
      deltaE,
      userFamily,
      targetFamily,
      description: `Matiz muy cercano (${describeColorName(userHex)}) aceptado`,
    };
  }

  // 4. Mismatch: wrong color family or excessive divergence
  const penaltyScore = Math.max(0, Math.round(100 - deltaE * 1.8));
  return {
    isMatch: false,
    score: penaltyScore,
    deltaE,
    userFamily,
    targetFamily,
    description: `Color no correspondiente (esperado ${describeColorName(targetHex)}, usado ${describeColorName(userHex)})`,
  };
}

/**
 * Human-friendly color name descriptor
 */
export function describeColorName(hex: string): string {
  const rgb = hexToRgb(hex);
  const r = rgb.r;
  const g = rgb.g;
  const b = rgb.b;

  // Grays / White / Black
  if (Math.abs(r - g) < 20 && Math.abs(g - b) < 20 && Math.abs(r - b) < 20) {
    if (r > 220) return 'Blanco';
    if (r < 40) return 'Negro';
    if (r < 120) return 'Gris oscuro';
    return 'Gris';
  }

  // Hues
  if (r > 180 && g < 70 && b < 70) return 'Rojo';
  if (r > 180 && g > 100 && g < 170 && b < 60) return 'Naranja';
  if (r > 190 && g > 180 && b < 80) return 'Amarillo';
  if (r > 180 && g > 140 && b < 60) return 'Dorado / Ocre';
  if (g > 140 && r < 80 && b < 80) return 'Verde';
  if (g > 140 && r < 100 && b > 120) return 'Turquesa / Cian';
  if (b > 160 && r < 100 && g < 140) return 'Azul';
  if (b > 160 && g > 150 && r < 120) return 'Azul celeste';
  if (b < 80 && r < 60 && g < 100) return 'Verde oscuro';
  if (b < 80 && r < 60 && g < 60) return 'Azul marino oscuro';
  if (r > 140 && b > 140 && g < 80) return 'Morado / Púrpura';
  if (r > 150 && g < 80 && b < 60) return 'Granate / Marrón rojizo';

  return `Color ${hex}`;
}
