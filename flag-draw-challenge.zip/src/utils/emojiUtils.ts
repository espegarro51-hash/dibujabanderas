/**
 * Converts a 2-letter ISO country code (e.g. "es", "fr", "us") into its corresponding flag emoji.
 */
export function getCountryFlagEmoji(countryId: string): string {
  if (!countryId || countryId.length < 2) return '🏳️';
  const code = countryId.slice(0, 2).toUpperCase();
  const first = 127397 + code.charCodeAt(0);
  const second = 127397 + code.charCodeAt(1);
  return String.fromCodePoint(first, second);
}
