import { CountryFlag, EvaluationResult, EvaluationDetailItem, EvaluationCategoryScores } from '../types';
import {
  hexToRgb,
  rgbToLab,
  deltaE94,
  rgbToHex,
  describeColorName,
  isColorToneMatch,
  getColorFamily,
  ColorFamily,
  Lab,
} from './colorUtils';
import { getFlagImageUrl } from '../data/countries';

/**
 * Loads an image from URL or base64 into an HTMLImageElement
 */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Failed to load image: ${src}`));
    img.src = src;
  });
}

/**
 * Intelligent evaluation engine:
 * - Comprehends flag geometric structure (horizontal/vertical stripes, triangles, cantons, crosses, center circles, diagonals).
 * - Recognizes valid color families and tone variations (distinguishing subtle tones properly without failing valid shades).
 * - Proportions are NOT scored or penalized as requested by the user.
 * - Strict and smart, giving precise semantic feedback.
 */
export async function evaluateDrawing(
  userCanvas: HTMLCanvasElement,
  country: CountryFlag,
  _isExtremeUnused: boolean = true,
  hintsUsed: number = 0
): Promise<EvaluationResult> {
  const feedbackItems: EvaluationDetailItem[] = [];

  // Standardized evaluation dimensions
  const evalWidth = 240;
  const evalHeight = Math.round(240 / country.ratioValue);

  // 1. Prepare User Evaluation Canvas
  const userEvalCanvas = document.createElement('canvas');
  userEvalCanvas.width = evalWidth;
  userEvalCanvas.height = evalHeight;
  const userCtx = userEvalCanvas.getContext('2d', { willReadFrequently: true });
  if (!userCtx) throw new Error('Could not get user canvas context');

  // Fill white initially, then draw user canvas
  userCtx.fillStyle = '#FFFFFF';
  userCtx.fillRect(0, 0, evalWidth, evalHeight);
  userCtx.drawImage(userCanvas, 0, 0, evalWidth, evalHeight);
  const userData = userCtx.getImageData(0, 0, evalWidth, evalHeight);

  // 2. Prepare Reference Evaluation Canvas
  const refEvalCanvas = document.createElement('canvas');
  refEvalCanvas.width = evalWidth;
  refEvalCanvas.height = evalHeight;
  const refCtx = refEvalCanvas.getContext('2d', { willReadFrequently: true });
  if (!refCtx) throw new Error('Could not get ref canvas context');

  try {
    const refImg = await loadImage(getFlagImageUrl(country.id));
    refCtx.drawImage(refImg, 0, 0, evalWidth, evalHeight);
  } catch {
    // Fallback: draw programmatic structure if network fails
    drawProgrammaticFallback(refCtx, country, evalWidth, evalHeight);
  }
  const refData = refCtx.getImageData(0, 0, evalWidth, evalHeight);

  // Base64 snapshots for visual comparison
  const userImageBase64 = userEvalCanvas.toDataURL('image/png');
  const referenceImageBase64 = refEvalCanvas.toDataURL('image/png');

  // Helper to read pixel Lab at (x, y)
  const getPixelLab = (data: ImageData, x: number, y: number): Lab => {
    const clX = Math.max(0, Math.min(evalWidth - 1, Math.round(x)));
    const clY = Math.max(0, Math.min(evalHeight - 1, Math.round(y)));
    const idx = (clY * evalWidth + clX) * 4;
    return rgbToLab({
      r: data.data[idx],
      g: data.data[idx + 1],
      b: data.data[idx + 2],
    });
  };

  // Helper to read pixel Hex at (x, y)
  const getPixelHex = (data: ImageData, x: number, y: number): string => {
    const clX = Math.max(0, Math.min(evalWidth - 1, Math.round(x)));
    const clY = Math.max(0, Math.min(evalHeight - 1, Math.round(y)));
    const idx = (clY * evalWidth + clX) * 4;
    return rgbToHex(data.data[idx], data.data[idx + 1], data.data[idx + 2]);
  };

  // Helper to sample dominant color in a rectangular region
  const getRegionDominantHex = (
    data: ImageData,
    startX: number,
    startY: number,
    width: number,
    height: number
  ): { hex: string; family: ColorFamily } => {
    const counts = new Map<string, number>();
    const step = 3;
    let maxHex = '#FFFFFF';
    let maxCount = 0;

    for (let y = startY; y < startY + height; y += step) {
      for (let x = startX; x < startX + width; x += step) {
        const hex = getPixelHex(data, x, y);
        const count = (counts.get(hex) || 0) + 1;
        counts.set(hex, count);
        if (count > maxCount) {
          maxCount = count;
          maxHex = hex;
        }
      }
    }
    return { hex: maxHex, family: getColorFamily(maxHex) };
  };

  // Step A: Blank Canvas / Inactivity Check
  let nonWhiteOrColoredCount = 0;
  const sampleStep = 3;
  for (let y = 0; y < evalHeight; y += sampleStep) {
    for (let x = 0; x < evalWidth; x += sampleStep) {
      const idx = (y * evalWidth + x) * 4;
      const r = userData.data[idx];
      const g = userData.data[idx + 1];
      const b = userData.data[idx + 2];
      if (r < 245 || g < 245 || b < 245) {
        nonWhiteOrColoredCount++;
      }
    }
  }

  const sampledTotal = (evalHeight / sampleStep) * (evalWidth / sampleStep);
  const drawnRatio = nonWhiteOrColoredCount / sampledTotal;
  const drawnPixelsPercentage = Math.round(drawnRatio * 100);

  const isFlagMostlyWhite = country.officialColors.some(
    (c) => c.hex.toUpperCase() === '#FFFFFF' && (c.approxPercent || 0) > 60
  );

  if (drawnRatio < 0.08 && !isFlagMostlyWhite) {
    feedbackItems.push({
      type: 'error',
      category: 'structure',
      title: 'Lienzo prácticamente vacío',
      description: 'Apenas has dibujado en el lienzo o se trata de un simple trazo sin completar.',
      pointsChange: -80,
    });

    return {
      score: Math.min(10, Math.round(drawnPixelsPercentage)),
      tier: 'wrong',
      tierLabel: 'Incorrecta',
      tierColor: '#EF4444',
      categoryScores: { colors: 10, structure: 5, symbols: 0, proportions: 100 },
      feedbackItems,
      userImageBase64,
      referenceImageBase64,
      isExtreme: false,
      drawnPixelsPercentage,
      hintsUsed,
      isPassed: false,
    };
  }

  // =========================================================================
  // Step B: Intelligent Color Palette Analysis
  // Recognizes matching tones/shades within the correct color family while
  // distinguishing subtle tone differences and penalizing totally wrong hues.
  // Tolerates close shades without harsh deductions.
  // =========================================================================
  let colorScore = 100;
  const userColorHistogram = new Map<string, number>();
  let userTotalSampled = 0;

  for (let y = 0; y < evalHeight; y += 4) {
    for (let x = 0; x < evalWidth; x += 4) {
      const hex = getPixelHex(userData, x, y);

      // For Nepal: do NOT count outer canvas background in the flag's color histogram
      if (country.id === 'np') {
        const relX = x / evalWidth;
        const relY = y / evalHeight;
        const isWhite = isColorToneMatch(hex, '#FFFFFF').isMatch;
        // Outside Nepal's double-pennant flag: upper-right quadrant or far-right fly
        const isOutsidePennants = (relX > 0.45 && relY < 0.48) || (relX > 0.85);
        if (isWhite && isOutsidePennants) {
          continue; // Skip outer canvas white space
        }
      }

      userColorHistogram.set(hex, (userColorHistogram.get(hex) || 0) + 1);
      userTotalSampled++;
    }
  }

  const matchedOfficialColors: string[] = [];

  for (const official of country.officialColors) {
    let bestMatchScore = 0;
    let bestDeltaE = 999;
    let bestUserHex = '';
    let isMatched = false;
    let matchDescription = '';

    // In Nepal, white is specifically for the moon and sun symbols inside the pennant
    if (country.id === 'np' && official.hex.toUpperCase() === '#FFFFFF') {
      let whiteInsidePennantCount = 0;
      // Check top pennant symbol zone (moon) and bottom pennant symbol zone (sun)
      for (let sy = Math.floor(evalHeight * 0.15); sy <= Math.floor(evalHeight * 0.85); sy += 3) {
        for (let sx = Math.floor(evalWidth * 0.15); sx <= Math.floor(evalWidth * 0.40); sx += 3) {
          const uHex = getPixelHex(userData, sx, sy);
          if (isColorToneMatch(uHex, '#FFFFFF').isMatch) {
            whiteInsidePennantCount++;
          }
        }
      }
      if (whiteInsidePennantCount >= 4) {
        isMatched = true;
        bestMatchScore = 95;
        bestDeltaE = 0;
        bestUserHex = '#FFFFFF';
      }
    } else {
      for (const [uHex, count] of userColorHistogram.entries()) {
        // Ignore minimal stray pixels (<1.2% of canvas)
        if (count / userTotalSampled < 0.012) continue;

        const toneCheck = isColorToneMatch(uHex, official.hex);
        if (toneCheck.isMatch) {
          if (toneCheck.score > bestMatchScore) {
            bestMatchScore = toneCheck.score;
            bestDeltaE = toneCheck.deltaE;
            bestUserHex = uHex;
            isMatched = true;
            matchDescription = toneCheck.description;
          }
        } else if (toneCheck.deltaE < bestDeltaE) {
          bestDeltaE = toneCheck.deltaE;
          bestUserHex = uHex;
        }
      }
    }

    if (isMatched) {
      matchedOfficialColors.push(official.name);
      const isPerfectTone = bestDeltaE <= 14.0;
      
      // If tone is close/acceptable (score >= 90), do not deduct points from colorScore
      if (bestMatchScore < 90) {
        colorScore -= Math.max(0, 90 - bestMatchScore);
      }

      feedbackItems.push({
        type: 'success',
        category: 'color',
        title: `${official.name}: color reconocido`,
        description: isPerfectTone
          ? `Has acertado el tono exacto de ${official.name}.`
          : `El tono utilizado (${describeColorName(bestUserHex)}) es adecuado y reconocido para ${official.name}.`,
        pointsChange: isPerfectTone ? 15 : 12,
      });
    } else {
      // Color missing or completely wrong family
      const penalty = 25;
      colorScore -= penalty;
      feedbackItems.push({
        type: 'error',
        category: 'color',
        title: `Falta el color: ${official.name}`,
        description: `No se ha detectado el tono o familia de ${official.name} (${official.hex}) en tu bandera.`,
        pointsChange: -penalty,
      });
    }
  }

  // Check for foreign/unauthorized rogue colors (colors that don't match any official color family)
  // Allows up to 12% stray outline/anti-aliasing pixels without penalty
  let roguePixels = 0;
  for (const [uHex, count] of userColorHistogram.entries()) {
    const isAnyOfficialFamily = country.officialColors.some((off) => {
      const match = isColorToneMatch(uHex, off.hex);
      return match.isMatch || match.deltaE <= 28.0;
    });

    if (!isAnyOfficialFamily) {
      roguePixels += count;
    }
  }

  const rogueRatio = roguePixels / userTotalSampled;
  if (rogueRatio > 0.12) {
    const roguePenalty = Math.min(25, Math.round((rogueRatio - 0.12) * 50));
    colorScore -= roguePenalty;
    feedbackItems.push({
      type: 'error',
      category: 'color',
      title: 'Colores ajenos a la bandera',
      description: `Se han detectado zonas con colores que no pertenecen a esta bandera (${Math.round(rogueRatio * 100)}% del dibujo).`,
      pointsChange: -roguePenalty,
    });
  }

  colorScore = Math.max(0, Math.min(100, colorScore));

  // =========================================================================
  // Step C: Intelligent Flag Structure Understanding
  // Comprehends horizontal/vertical stripes, hoist triangles, cantons, crosses,
  // central circles, diagonals, and plain layouts with tolerance for natural
  // hand-drawn lines, slight wobbles, and small deformities.
  // =========================================================================
  let structureScore = 100;
  const struct = country.structure;

  if (country.id === 'np') {
    // Dedicated strict evaluation for Nepal's double-pennant non-quadrangular geometry
    // 1. Check upper-right void: (x in [0.55, 0.90], y in [0.08, 0.38])
    // Must NOT be painted red or blue (must be white/unpainted canvas)
    let paintedInUpperVoid = 0;
    let totalVoidChecks = 0;
    for (let vy = Math.floor(evalHeight * 0.08); vy <= Math.floor(evalHeight * 0.38); vy += 6) {
      for (let vx = Math.floor(evalWidth * 0.58); vx <= Math.floor(evalWidth * 0.90); vx += 6) {
        const hex = getPixelHex(userData, vx, vy);
        const isWhite = isColorToneMatch(hex, '#FFFFFF').isMatch;
        if (!isWhite) paintedInUpperVoid++;
        totalVoidChecks++;
      }
    }
    const voidRatio = paintedInUpperVoid / Math.max(1, totalVoidChecks);

    // 2. Check top pennant core (around relX: 0.22, relY: 0.28)
    const topPennant = getRegionDominantHex(userData, Math.floor(evalWidth * 0.15), Math.floor(evalHeight * 0.20), 20, 20);
    const topIsRed = isColorToneMatch(topPennant.hex, '#DC143C').isMatch;

    // 3. Check bottom pennant core (around relX: 0.22, relY: 0.72)
    const bottomPennant = getRegionDominantHex(userData, Math.floor(evalWidth * 0.15), Math.floor(evalHeight * 0.65), 20, 20);
    const bottomIsRed = isColorToneMatch(bottomPennant.hex, '#DC143C').isMatch;

    // 4. Check blue border on pennants
    let hasBlueBorder = false;
    for (const [uHex] of userColorHistogram.entries()) {
      if (isColorToneMatch(uHex, '#003893').isMatch) {
        hasBlueBorder = true;
        break;
      }
    }

    if (voidRatio > 0.35) {
      structureScore -= 50;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Forma no cuadrangular de Nepal',
        description: 'Nepal no es una bandera rectangular. Debe tener forma de dos banderines triangulares con la esquina superior derecha vacía.',
        pointsChange: -50,
      });
    } else if (topIsRed && bottomIsRed && hasBlueBorder) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Doble banderín de Nepal reconocido',
        description: 'Has dibujado correctamente la silueta de dos triángulos rojos ribeteados de azul con el vacío exterior correspondiente.',
        pointsChange: 30,
      });
    } else {
      structureScore -= 35;
      feedbackItems.push({
        type: 'warning',
        category: 'structure',
        title: 'Silueta de Nepal incompleta',
        description: 'Se requiere el doble triángulo rojo con borde azul exterior y espacio vacío en la zona superior derecha.',
        pointsChange: -35,
      });
    }
  } else if (struct.type === 'horizontal_stripes') {
    const count = struct.stripeCount || struct.stripeColors?.length || 3;
    const stripeColors = struct.stripeColors || country.officialColors.map((c) => c.hex);
    const ratios = struct.stripeRatios || Array(count).fill(1);
    const sumRatios = ratios.reduce((a, b) => a + b, 0);

    // Multi-column sampling across 7 columns (15%, 25%, 35%, 50%, 65%, 75%, 85%)
    const sampleCols = [
      Math.floor(evalWidth * 0.15),
      Math.floor(evalWidth * 0.25),
      Math.floor(evalWidth * 0.35),
      Math.floor(evalWidth * 0.5),
      Math.floor(evalWidth * 0.65),
      Math.floor(evalWidth * 0.75),
      Math.floor(evalWidth * 0.85),
    ];

    let correctStripeMatches = 0;
    let totalStripeChecks = 0;
    let invertedOrderMatches = 0;

    let curY = 0;
    for (let i = 0; i < count; i++) {
      const stripeH = (ratios[i] / sumRatios) * evalHeight;
      // Sample central corridor of the stripe (avoiding boundary jitter from hand drawing)
      const corridorY = curY + stripeH * 0.5;
      const expectedHex = stripeColors[i % stripeColors.length];
      const invertedExpectedHex = stripeColors[count - 1 - (i % stripeColors.length)];

      for (const colX of sampleCols) {
        const userHex = getPixelHex(userData, colX, Math.floor(corridorY));
        const match = isColorToneMatch(userHex, expectedHex);
        const invMatch = isColorToneMatch(userHex, invertedExpectedHex);

        if (match.isMatch) {
          correctStripeMatches++;
        }
        if (invMatch.isMatch) {
          invertedOrderMatches++;
        }
        totalStripeChecks++;
      }
      curY += stripeH;
    }

    const accuracy = correctStripeMatches / totalStripeChecks;
    const invAccuracy = invertedOrderMatches / totalStripeChecks;

    // Tolerance for hand-drawn deformities: >= 65% accuracy across the band corridor counts as fully valid!
    if (accuracy >= 0.65) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Franjas horizontales en orden correcto',
        description: `Las ${count} franjas horizontales siguen la secuencia oficial (reconocidas con tolerancia al trazo a mano).`,
        pointsChange: 25,
      });
    } else if (invAccuracy >= 0.65 && invAccuracy > accuracy) {
      structureScore -= 50;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Franjas horizontales invertidas',
        description: `Has dibujado los colores de las franjas al revés (orden invertido de arriba hacia abajo).`,
        pointsChange: -50,
      });
    } else if (accuracy >= 0.40) {
      structureScore -= 12;
      feedbackItems.push({
        type: 'warning',
        category: 'structure',
        title: 'Franjas con ligera irregularidad',
        description: 'La orientación es horizontal pero algunas zonas presentan desalineación en sus colores.',
        pointsChange: -12,
      });
    } else {
      structureScore -= 45;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Estructura de franjas incorrecta',
        description: 'La estructura dibujada no corresponde con las franjas horizontales de la bandera.',
        pointsChange: -45,
      });
    }
  } else if (struct.type === 'vertical_stripes') {
    const count = struct.stripeCount || struct.stripeColors?.length || 3;
    const stripeColors = struct.stripeColors || country.officialColors.map((c) => c.hex);
    const ratios = struct.stripeRatios || Array(count).fill(1);
    const sumRatios = ratios.reduce((a, b) => a + b, 0);

    // Multi-row sampling across 7 rows (15%, 25%, 35%, 50%, 65%, 75%, 85%)
    const sampleRows = [
      Math.floor(evalHeight * 0.15),
      Math.floor(evalHeight * 0.25),
      Math.floor(evalHeight * 0.35),
      Math.floor(evalHeight * 0.5),
      Math.floor(evalHeight * 0.65),
      Math.floor(evalHeight * 0.75),
      Math.floor(evalHeight * 0.85),
    ];

    let correctStripeMatches = 0;
    let totalStripeChecks = 0;
    let invertedOrderMatches = 0;

    let curX = 0;
    for (let i = 0; i < count; i++) {
      const stripeW = (ratios[i] / sumRatios) * evalWidth;
      // Sample central corridor of the stripe
      const corridorX = curX + stripeW * 0.5;
      const expectedHex = stripeColors[i % stripeColors.length];
      const invertedExpectedHex = stripeColors[count - 1 - (i % stripeColors.length)];

      for (const rowY of sampleRows) {
        const userHex = getPixelHex(userData, Math.floor(corridorX), rowY);
        const match = isColorToneMatch(userHex, expectedHex);
        const invMatch = isColorToneMatch(userHex, invertedExpectedHex);

        if (match.isMatch) {
          correctStripeMatches++;
        }
        if (invMatch.isMatch) {
          invertedOrderMatches++;
        }
        totalStripeChecks++;
      }
      curX += stripeW;
    }

    const accuracy = correctStripeMatches / totalStripeChecks;
    const invAccuracy = invertedOrderMatches / totalStripeChecks;

    // Tolerance for hand-drawn deformities: >= 65% accuracy across the band corridor counts as fully valid!
    if (accuracy >= 0.65) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Franjas verticales bien ordenadas',
        description: `Las ${count} franjas verticales están en la secuencia correcta de izquierda a derecha.`,
        pointsChange: 25,
      });
    } else if (invAccuracy >= 0.65 && invAccuracy > accuracy) {
      structureScore -= 50;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Franjas verticales invertidas',
        description: `Has colocado los colores al revés (la franja del asta está en la derecha).`,
        pointsChange: -50,
      });
    } else if (accuracy >= 0.40) {
      structureScore -= 12;
      feedbackItems.push({
        type: 'warning',
        category: 'structure',
        title: 'Franjas verticales con ligera irregularidad',
        description: 'La división es vertical pero el orden o delimitación tiene pequeñas imprecisiones.',
        pointsChange: -12,
      });
    } else {
      structureScore -= 45;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Estructura vertical no reconocida',
        description: 'No se ha detectado el patrón vertical característico de esta bandera.',
        pointsChange: -45,
      });
    }
  } else if (struct.type === 'triangle_hoist') {
    // E.g. Czechia, Cuba, Jordan, Sudan, Philippines, Bahamas
    const triangleColor = struct.triangleColor || country.officialColors[0].hex;
    const stripeColors = struct.stripeColors || [country.officialColors[1]?.hex || '#FFFFFF', country.officialColors[2]?.hex || '#D7141A'];

    // 1. Check hoist triangle core (near the hoist, centered vertically)
    const triangleSample = getRegionDominantHex(userData, Math.floor(evalWidth * 0.08), Math.floor(evalHeight * 0.35), 25, 30);
    const triangleMatch = isColorToneMatch(triangleSample.hex, triangleColor);

    // 2. Check top-right stripe and bottom-right stripe cores (well outside triangle)
    const topStripeSample = getRegionDominantHex(userData, Math.floor(evalWidth * 0.65), Math.floor(evalHeight * 0.2), 30, 20);
    const bottomStripeSample = getRegionDominantHex(userData, Math.floor(evalWidth * 0.65), Math.floor(evalHeight * 0.75), 30, 20);

    const topMatch = isColorToneMatch(topStripeSample.hex, stripeColors[0]);
    const bottomMatch = isColorToneMatch(bottomStripeSample.hex, stripeColors[stripeColors.length - 1]);

    if (triangleMatch.isMatch && topMatch.isMatch && bottomMatch.isMatch) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Triángulo en el asta y franjas correctas',
        description: 'La composición del triángulo lateral y las franjas horizontales ha sido reconocida correctamente.',
        pointsChange: 30,
      });
    } else if (triangleMatch.isMatch) {
      structureScore -= 15;
      feedbackItems.push({
        type: 'warning',
        category: 'structure',
        title: 'Triángulo detectado, franjas con desvío',
        description: 'Has colocado el triángulo en el asta, pero los colores o el orden de las franjas difieren del oficial.',
        pointsChange: -15,
      });
    } else {
      structureScore -= 45;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Falta el triángulo del asta',
        description: 'No se detectó el triángulo lateral característico en el lado izquierdo.',
        pointsChange: -45,
      });
    }
  } else if (struct.type === 'canton') {
    // E.g. Greece, USA, Uruguay, Chile, Malaysia, Liberia
    const cantonColor = struct.cantonColor || country.officialColors[0].hex;
    const cantonSample = getRegionDominantHex(userData, 5, 5, Math.floor(evalWidth * 0.28), Math.floor(evalHeight * 0.35));
    const cantonMatch = isColorToneMatch(cantonSample.hex, cantonColor);

    if (cantonMatch.isMatch) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Cantón superior izquierdo reconocido',
        description: 'El cuadrante del cantón y el campo circundante han sido identificados correctamente.',
        pointsChange: 25,
      });
    } else {
      structureScore -= 35;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Cantón superior izquierdo ausente o incorrecto',
        description: 'No se identificó el cantón rectangular en la esquina superior izquierda.',
        pointsChange: -35,
      });
    }
  } else if (struct.type === 'cross' || struct.type === 'nordic_cross') {
    // E.g. Sweden, Norway, Denmark, Finland, Iceland, Switzerland, England
    const isNordic = struct.type === 'nordic_cross';
    const crossCenterX = Math.floor(evalWidth * (isNordic ? 0.35 : 0.5));
    const crossCenterY = Math.floor(evalHeight * 0.5);

    // Cross center intersection
    const centerHex = getPixelHex(userData, crossCenterX, crossCenterY);
    // Background corner regions
    const bgCornerHex1 = getPixelHex(userData, Math.floor(evalWidth * 0.8), Math.floor(evalHeight * 0.2));
    const bgCornerHex2 = getPixelHex(userData, Math.floor(evalWidth * 0.8), Math.floor(evalHeight * 0.8));

    const crossRefColor = struct.backgroundColor ? (country.officialColors.find((c) => c.hex !== struct.backgroundColor)?.hex || country.officialColors[0].hex) : country.officialColors[0].hex;
    const bgRefColor = struct.backgroundColor || country.officialColors[1]?.hex || '#FFFFFF';

    const crossMatch = isColorToneMatch(centerHex, crossRefColor);
    const bgMatch = isColorToneMatch(bgCornerHex1, bgRefColor) || isColorToneMatch(bgCornerHex2, bgRefColor);

    if (crossMatch.isMatch && bgMatch) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: isNordic ? 'Cruz nórdica identificada' : 'Estructura de cruz identificada',
        description: 'La cruz y los cuadrantes de fondo se encuentran en la posición correspondiente.',
        pointsChange: 25,
      });
    } else if (crossMatch.isMatch || bgMatch) {
      structureScore -= 15;
      feedbackItems.push({
        type: 'warning',
        category: 'structure',
        title: 'Cruz o cuadrantes con imprecisiones',
        description: 'Se detecta la división de cruz pero con leves desajustes en el color de los brazos o del fondo.',
        pointsChange: -15,
      });
    } else {
      structureScore -= 40;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Falta la estructura de cruz',
        description: 'No se detectó el patrón de cruz sobre el fondo de la bandera.',
        pointsChange: -40,
      });
    }
  } else if (struct.type === 'circle_center') {
    // E.g. Japan, Bangladesh, Palau, Niger
    const circleX = Math.floor(evalWidth * 0.5);
    const circleY = Math.floor(evalHeight * 0.5);
    const circleHex = getPixelHex(userData, circleX, circleY);
    const cornerHex = getPixelHex(userData, 10, 10);

    const circleTarget = country.officialColors[0].hex;
    const bgTarget = struct.backgroundColor || country.officialColors[1]?.hex || '#FFFFFF';

    const circleMatch = isColorToneMatch(circleHex, circleTarget);
    const bgMatch = isColorToneMatch(cornerHex, bgTarget);

    if (circleMatch.isMatch && bgMatch) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Disco central y fondo correctos',
        description: 'Se ha identificado el círculo central y el color de fondo correspondiente.',
        pointsChange: 25,
      });
    } else {
      structureScore -= 35;
      feedbackItems.push({
        type: 'error',
        category: 'structure',
        title: 'Disco central no reconocido',
        description: 'No se ha detectado el círculo central sobre el fondo esperado.',
        pointsChange: -35,
      });
    }
  } else {
    // Fallback general dense quadrant & layout check
    const qUser = [
      getRegionDominantHex(userData, 0, 0, evalWidth / 2, evalHeight / 2),
      getRegionDominantHex(userData, evalWidth / 2, 0, evalWidth / 2, evalHeight / 2),
      getRegionDominantHex(userData, 0, evalHeight / 2, evalWidth / 2, evalHeight / 2),
      getRegionDominantHex(userData, evalWidth / 2, evalHeight / 2, evalWidth / 2, evalHeight / 2),
    ];
    const qRef = [
      getRegionDominantHex(refData, 0, 0, evalWidth / 2, evalHeight / 2),
      getRegionDominantHex(refData, evalWidth / 2, 0, evalWidth / 2, evalHeight / 2),
      getRegionDominantHex(refData, 0, evalHeight / 2, evalWidth / 2, evalHeight / 2),
      getRegionDominantHex(refData, evalWidth / 2, evalHeight / 2, evalWidth / 2, evalHeight / 2),
    ];

    let quadrantMatches = 0;
    for (let q = 0; q < 4; q++) {
      if (isColorToneMatch(qUser[q].hex, qRef[q].hex).isMatch) {
        quadrantMatches++;
      }
    }

    if (quadrantMatches >= 3) {
      feedbackItems.push({
        type: 'success',
        category: 'structure',
        title: 'Distribución general correcta',
        description: 'La disposición de los cuadrantes y zonas del diseño concuerda con la bandera oficial.',
        pointsChange: 20,
      });
    } else {
      structureScore -= 25;
      feedbackItems.push({
        type: 'warning',
        category: 'structure',
        title: 'Desalineación en la distribución general',
        description: 'La colocación espacial de los elementos no coincide con el mapa de la bandera.',
        pointsChange: -25,
      });
    }
  }

  structureScore = Math.max(0, Math.min(100, structureScore));

  // =========================================================================
  // Step D: Symbols & Emblems Analysis
  // Tolerates hand-drawn positioning offset (up to 16% of canvas) without penalty.
  // =========================================================================
  let symbolsScore = 100;
  if (country.symbols.length > 0) {
    for (const sym of country.symbols) {
      const targetCenterX = Math.round(sym.approxX * evalWidth);
      const targetCenterY = Math.round(sym.approxY * evalHeight);
      const searchRadius = Math.max(12, Math.round((sym.relativeSize * evalWidth) * 0.85));

      // Scan surrounding box for distinct foreground marks
      let foundForegroundPixels = 0;
      let sumX = 0;
      let sumY = 0;

      for (
        let y = Math.max(0, targetCenterY - searchRadius * 2);
        y <= Math.min(evalHeight - 1, targetCenterY + searchRadius * 2);
        y += 2
      ) {
        for (
          let x = Math.max(0, targetCenterX - searchRadius * 2);
          x <= Math.min(evalWidth - 1, targetCenterX + searchRadius * 2);
          x += 2
        ) {
          const uHex = getPixelHex(userData, x, y);
          const toneCheck = isColorToneMatch(uHex, sym.color);
          if (toneCheck.isMatch || toneCheck.deltaE <= 25) {
            foundForegroundPixels++;
            sumX += x;
            sumY += y;
          }
        }
      }

      if (foundForegroundPixels < 6) {
        const penalty = 35;
        symbolsScore -= penalty;
        feedbackItems.push({
          type: 'error',
          category: 'symbols',
          title: `Falta símbolo: ${sym.name}`,
          description: `No se ha detectado el elemento (${sym.name}) en la posición correspondiente.`,
          pointsChange: -penalty,
        });
      } else {
        const detectedCenterX = sumX / foundForegroundPixels;
        const detectedCenterY = sumY / foundForegroundPixels;
        const offsetX = Math.abs(detectedCenterX - targetCenterX) / evalWidth;
        const offsetY = Math.abs(detectedCenterY - targetCenterY) / evalHeight;
        const totalOffset = Math.sqrt(offsetX * offsetX + offsetY * offsetY);

        // Generous tolerance for natural hand-drawn symbol placement (up to 16% offset is 100% accepted)
        if (totalOffset <= 0.16) {
          feedbackItems.push({
            type: 'success',
            category: 'symbols',
            title: `Símbolo ubicado: ${sym.name}`,
            description: `El elemento ${sym.name} ha sido detectado en la posición adecuada.`,
            pointsChange: 15,
          });
        } else if (totalOffset <= 0.28) {
          const penalty = 6;
          symbolsScore -= penalty;
          feedbackItems.push({
            type: 'warning',
            category: 'position',
            title: `Símbolo ligeramente desplazado: ${sym.name}`,
            description: `El símbolo ${sym.name} presenta un leve desvío respecto al centro oficial (${Math.round(totalOffset * 100)}%).`,
            pointsChange: -penalty,
          });
        } else {
          const penalty = 18;
          symbolsScore -= penalty;
          feedbackItems.push({
            type: 'warning',
            category: 'position',
            title: `Símbolo desplazado: ${sym.name}`,
            description: `El símbolo ${sym.name} está desplazado respecto a su posición oficial (${Math.round(totalOffset * 100)}% de desvío).`,
            pointsChange: -penalty,
          });
        }
      }
    }
  } else {
    // If flag has no symbols (e.g. France, Germany, Poland), verify user didn't draw unwanted symbols in center
    let centerMatchDiff = 0;
    const centerX = Math.round(evalWidth / 2);
    const centerY = Math.round(evalHeight / 2);
    const rad = 15;

    for (let dy = -rad; dy <= rad; dy += 3) {
      for (let dx = -rad; dx <= rad; dx += 3) {
        const uHex = getPixelHex(userData, centerX + dx, centerY + dy);
        const rHex = getPixelHex(refData, centerX + dx, centerY + dy);
        if (!isColorToneMatch(uHex, rHex).isMatch) {
          centerMatchDiff++;
        }
      }
    }

    if (centerMatchDiff > 40) {
      const penalty = 15;
      symbolsScore -= penalty;
      feedbackItems.push({
        type: 'warning',
        category: 'symbols',
        title: 'Trazos o manchas en zona lisa',
        description: 'La bandera oficial no lleva símbolos en esta zona, pero tu dibujo contiene trazos o manchas.',
        pointsChange: -penalty,
      });
    }
  }

  symbolsScore = Math.max(0, Math.min(100, symbolsScore));

  // =========================================================================
  // Step E: Overall Score Calculation (Proportions EXCLUDED)
  // Per user request: proportions are NOT scored or penalized.
  // =========================================================================
  const hasSymbols = country.symbols.length > 0;
  let rawScore = 0;

  if (hasSymbols) {
    // Structure: 50%, Colors: 35%, Symbols: 15%
    rawScore = structureScore * 0.5 + colorScore * 0.35 + symbolsScore * 0.15;
  } else {
    // Structure: 55%, Colors: 45%
    rawScore = structureScore * 0.55 + colorScore * 0.45;
  }

  // Strong drag down if a core component failed completely (e.g. completely wrong colors or inverted structure)
  if (colorScore < 40 || structureScore < 40) {
    rawScore *= 0.7;
  }

  // Apply Hints Penalty: -10% per hint used
  const hintsPenalty = hintsUsed * 10;
  if (hintsPenalty > 0) {
    feedbackItems.unshift({
      type: 'warning',
      category: 'color',
      title: `Penalización por pistas (-${hintsPenalty}%)`,
      description: `Has usado ${hintsUsed} pista(s). Se ha restado un 10% por cada pista de tu puntuación total.`,
      pointsChange: -hintsPenalty,
    });
  }

  const calculatedScore = rawScore - hintsPenalty;
  const finalScore = Math.max(0, Math.min(100, Math.round(calculatedScore)));
  const isPassed = finalScore >= 90;

  // Set categoryScores (proportions kept at 100 so it never counts against the user)
  const categoryScores: EvaluationCategoryScores = {
    colors: Math.max(0, Math.min(100, Math.round(colorScore))),
    structure: Math.max(0, Math.min(100, Math.round(structureScore))),
    symbols: Math.max(0, Math.min(100, Math.round(symbolsScore))),
    proportions: 100,
  };

  // Determine Tier (clean, neutral, natural labels)
  let tier: EvaluationResult['tier'] = 'wrong';
  let tierLabel = 'Incorrecta';
  let tierColor = '#EF4444';

  if (finalScore >= 95) {
    tier = 'perfect';
    tierLabel = '¡Perfecta! (100% Oficial)';
    tierColor = '#10B981';
  } else if (finalScore >= 90) {
    tier = 'excellent';
    tierLabel = 'Excelente (¡Aprobada y Racha +1!)';
    tierColor = '#22C55E';
  } else if (finalScore >= 75) {
    tier = 'good';
    tierLabel = 'Notable (Requiere ≥ 90 pts)';
    tierColor = '#EAB308';
  } else if (finalScore >= 50) {
    tier = 'partial';
    tierLabel = 'Parcialmente correcta';
    tierColor = '#F97316';
  } else if (finalScore >= 25) {
    tier = 'poor';
    tierLabel = 'Incompleta o con errores';
    tierColor = '#EF4444';
  } else {
    tier = 'wrong';
    tierLabel = 'Incorrecta o Garabato';
    tierColor = '#DC2626';
  }

  return {
    score: finalScore,
    tier,
    tierLabel,
    tierColor,
    categoryScores,
    feedbackItems,
    userImageBase64,
    referenceImageBase64,
    isExtreme: false,
    drawnPixelsPercentage,
    hintsUsed,
    isPassed,
  };
}

/**
 * Fallback procedural renderer for reference canvas if offline
 */
function drawProgrammaticFallback(
  ctx: CanvasRenderingContext2D,
  country: CountryFlag,
  width: number,
  height: number
) {
  ctx.fillStyle = country.structure.backgroundColor || '#FFFFFF';
  ctx.fillRect(0, 0, width, height);

  if (country.structure.type === 'horizontal_stripes' && country.structure.stripeColors) {
    const count = country.structure.stripeColors.length;
    const ratios = country.structure.stripeRatios || Array(count).fill(1);
    const sum = ratios.reduce((a, b) => a + b, 0);
    let curY = 0;
    for (let i = 0; i < count; i++) {
      const h = (ratios[i] / sum) * height;
      ctx.fillStyle = country.structure.stripeColors[i];
      ctx.fillRect(0, curY, width, h);
      curY += h;
    }
  } else if (country.structure.type === 'vertical_stripes' && country.structure.stripeColors) {
    const count = country.structure.stripeColors.length;
    const ratios = country.structure.stripeRatios || Array(count).fill(1);
    const sum = ratios.reduce((a, b) => a + b, 0);
    let curX = 0;
    for (let i = 0; i < count; i++) {
      const w = (ratios[i] / sum) * width;
      ctx.fillStyle = country.structure.stripeColors[i];
      ctx.fillRect(curX, 0, w, height);
      curX += w;
    }
  }
}
