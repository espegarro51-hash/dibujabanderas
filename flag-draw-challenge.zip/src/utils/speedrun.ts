import { SpeedrunRecord } from '../types';
import { getCountryFlagEmoji } from './emojiUtils';
import { getCountryById } from '../data/countries';

const SPEEDRUN_STORAGE_KEY = 'flag_draw_speedrun_leaderboards_v2';

// Tiebreaker logic per user request:
// "que gane el que tenga mas nota y si 2 tienen la misma nota hay desempate por tiempo"
export function compareSpeedrunRecords(a: SpeedrunRecord, b: SpeedrunRecord): number {
  if (b.score !== a.score) {
    return b.score - a.score; // Highest score first!
  }
  return a.timeSeconds - b.timeSeconds; // Lowest time first on tie!
}

// Filter out any mock/seed/bot records that might have been stored in previous versions
function filterRealPlayersOnly(records: SpeedrunRecord[]): SpeedrunRecord[] {
  const fakeNames = new Set(['VexilloMaster', 'AtlasSpeed', 'GeoRunner', 'FlashBrush', 'Bot', 'Jugador Inventado']);
  return records.filter((r) => {
    if (!r || !r.userName) return false;
    if (r.id && r.id.startsWith('seed-')) return false;
    if (fakeNames.has(r.userName.trim())) return false;
    return true;
  });
}

function getAllLeaderboards(): Record<string, SpeedrunRecord[]> {
  try {
    const raw = localStorage.getItem(SPEEDRUN_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Sanitize any existing lists to remove old mock/bot entries
      const sanitized: Record<string, SpeedrunRecord[]> = {};
      for (const [countryId, records] of Object.entries(parsed)) {
        if (Array.isArray(records)) {
          sanitized[countryId] = filterRealPlayersOnly(records);
        }
      }
      return sanitized;
    }
  } catch (err) {
    console.error('Error reading speedrun leaderboards:', err);
  }
  return {};
}

function saveAllLeaderboards(data: Record<string, SpeedrunRecord[]>): void {
  try {
    localStorage.setItem(SPEEDRUN_STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Error saving speedrun leaderboards:', err);
  }
}

/**
 * Returns the sorted leaderboard for a specific country containing ONLY real players who logged in.
 * Ranked primarily by Score (descending), tiebroken by Time (ascending).
 * Returns empty array [] if no real player has played this flag yet.
 */
export function getCountryLeaderboard(countryId: string, countryName?: string): SpeedrunRecord[] {
  const all = getAllLeaderboards();
  const list = all[countryId] || [];
  return filterRealPlayersOnly(list).sort(compareSpeedrunRecords);
}

/**
 * Saves a new speedrun record for a country and returns the updated leaderboard
 * and the player's rank (1-indexed).
 */
export function saveSpeedrunRecord(record: SpeedrunRecord): {
  rank: number;
  isPodium: boolean;
  isFirstPlace: boolean;
  leaderboard: SpeedrunRecord[];
} {
  const all = getAllLeaderboards();
  const currentList = getCountryLeaderboard(record.countryId, record.countryName);

  // Add record and sort
  const updated = [...currentList, record].sort(compareSpeedrunRecords);

  // Keep top 100 entries per flag
  const capped = updated.slice(0, 100);
  all[record.countryId] = capped;
  saveAllLeaderboards(all);

  const rank = capped.findIndex((r) => r.id === record.id) + 1;

  return {
    rank: rank > 0 ? rank : capped.length,
    isPodium: rank >= 1 && rank <= 3,
    isFirstPlace: rank === 1,
    leaderboard: capped,
  };
}

/**
 * Gets the best record for a specific country (Rank #1)
 */
export function getCountryBestRecord(countryId: string, countryName: string): SpeedrunRecord | null {
  const lb = getCountryLeaderboard(countryId, countryName);
  return lb.length > 0 ? lb[0] : null;
}

/**
 * Format elapsed seconds to mm:ss.cc (e.g. 14.32s or 01:24.50)
 */
export function formatSpeedrunTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00.00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const hundredths = Math.floor((seconds % 1) * 100);

  const mm = mins.toString().padStart(2, '0');
  const ss = secs.toString().padStart(2, '0');
  const cc = hundredths.toString().padStart(2, '0');

  return mins > 0 ? `${mm}:${ss}.${cc}` : `${ss}.${cc}s`;
}

/**
 * Convenience helper to record a completed speedrun attempt and save it
 */
export function recordSpeedrunRun(
  countryId: string,
  score: number,
  timeSeconds: number,
  userName: string,
  userAvatar?: string
): SpeedrunRecord {
  const country = getCountryById(countryId);
  const countryName = country?.name || countryId.toUpperCase();
  const emoji = getCountryFlagEmoji(countryId);

  const record: SpeedrunRecord = {
    id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    countryId,
    countryName,
    countryEmoji: emoji,
    userName,
    userAvatar,
    score,
    timeSeconds,
    date: new Date().toISOString(),
    isPlayer: true,
  };

  saveSpeedrunRecord(record);
  return record;
}

/**
 * Gets player ranking info for a recently saved record
 */
export function getPlayerRank(
  countryId: string,
  recordId: string
): {
  rank: number;
  isPodium: boolean;
  isFirstPlace: boolean;
  leaderboard: SpeedrunRecord[];
} {
  const country = getCountryById(countryId);
  const countryName = country?.name || countryId.toUpperCase();
  const lb = getCountryLeaderboard(countryId, countryName);
  const rank = lb.findIndex((r) => r.id === recordId) + 1;

  return {
    rank: rank > 0 ? rank : lb.length,
    isPodium: rank >= 1 && rank <= 3,
    isFirstPlace: rank === 1,
    leaderboard: lb,
  };
}

