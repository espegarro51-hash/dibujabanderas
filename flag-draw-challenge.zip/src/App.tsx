import React, { useState, useEffect, useCallback, useRef } from 'react';
import { CountryFlag, GameMode, GameStats, EvaluationResult, Continent, SpeedrunRecord } from './types';
import { ALL_COUNTRIES, getRandomCountry, getCountryById } from './data/countries';
import { evaluateDrawing } from './utils/evaluator';
import { playSuccessSound, playFailSound, playClickSound } from './utils/audio';
import { getStoredUser, clearUser, GoogleUser } from './utils/auth';
import { recordSpeedrunRun, getPlayerRank } from './utils/speedrun';
import { DrawingCanvas } from './components/DrawingCanvas';
import { GameHeader } from './components/GameHeader';
import { EvaluationModal } from './components/EvaluationModal';
import { CountrySelectorModal } from './components/CountrySelectorModal';
import { GoogleLoginModal } from './components/GoogleLoginModal';
import { MainMenu } from './components/MainMenu';
import { SpeedrunPickerModal } from './components/SpeedrunPickerModal';
import { SpeedrunLeaderboardModal } from './components/SpeedrunLeaderboardModal';

const STATS_STORAGE_KEY = 'flag_draw_stats_v2';

const INITIAL_STATS: GameStats = {
  totalDrawn: 0,
  flagsCompleted: 0,
  perfectScores: 0,
  currentStreak: 0,
  bestStreak: 0,
  completedFlags: {},
};

export default function App() {
  // Google Auth User
  const [googleUser, setGoogleUser] = useState<GoogleUser | null>(() => getStoredUser());

  // Navigation: Main Menu vs Active Game Canvas
  const [isInMenu, setIsInMenu] = useState<boolean>(true);

  // Game Setup States
  const [currentCountry, setCurrentCountry] = useState<CountryFlag>(() => {
    return getCountryById('es') || ALL_COUNTRIES[0];
  });
  const [gameMode, setGameMode] = useState<GameMode>('aleatorio');
  const [selectedContinent, setSelectedContinent] = useState<Continent | undefined>(undefined);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Canvas & Evaluation
  const canvasElementRef = useRef<HTMLCanvasElement | null>(null);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<EvaluationResult | null>(null);

  // Speedrun Specific State
  const [speedrunRunKey, setSpeedrunRunKey] = useState<number>(0);
  const [lastSpeedrunTime, setLastSpeedrunTime] = useState<number | undefined>(undefined);
  const [speedrunRankInfo, setSpeedrunRankInfo] = useState<{
    rank: number;
    isPodium: boolean;
    isFirstPlace: boolean;
    leaderboard: SpeedrunRecord[];
  } | null>(null);

  // Modals
  const [isAtlasOpen, setIsAtlasOpen] = useState<boolean>(false);
  const [isSpeedrunPickerOpen, setIsSpeedrunPickerOpen] = useState<boolean>(false);
  const [isSpeedrunLeaderboardOpen, setIsSpeedrunLeaderboardOpen] = useState<boolean>(false);
  const [speedrunLeaderboardTargetCountry, setSpeedrunLeaderboardTargetCountry] = useState<CountryFlag | undefined>(undefined);

  // Stats
  const [stats, setStats] = useState<GameStats>(() => {
    try {
      const saved = localStorage.getItem(STATS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_STATS;
  });

  // Persist stats
  useEffect(() => {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    } catch {
      // ignore
    }
  }, [stats]);

  const handleCanvasReady = useCallback((canvas: HTMLCanvasElement) => {
    canvasElementRef.current = canvas;
  }, []);

  const handleSelectCountry = (country: CountryFlag) => {
    setCurrentCountry(country);
    setEvaluationResult(null);
    setIsInMenu(false);
  };

  const handleSelectSpeedrunCountry = (country: CountryFlag) => {
    setGameMode('speedrun');
    setCurrentCountry(country);
    setEvaluationResult(null);
    setLastSpeedrunTime(undefined);
    setSpeedrunRankInfo(null);
    setSpeedrunRunKey((k) => k + 1);
    setIsInMenu(false);
    setIsSpeedrunPickerOpen(false);
    setIsSpeedrunLeaderboardOpen(false);
  };

  const handleNextRandom = useCallback(() => {
    const onlyDifficult = gameMode === 'dificiles';
    const continentFilter = gameMode === 'continente' ? selectedContinent : undefined;
    const next = getRandomCountry(currentCountry.id, continentFilter, onlyDifficult);
    setCurrentCountry(next);
    setEvaluationResult(null);
    setLastSpeedrunTime(undefined);
    setSpeedrunRankInfo(null);
    setSpeedrunRunKey((k) => k + 1);
  }, [currentCountry.id, gameMode, selectedContinent]);

  // Submit drawing to evaluator
  const handleSubmitDrawing = async (hintsUsed: number = 0, elapsedTimeSeconds: number = 0) => {
    if (!canvasElementRef.current || isEvaluating) return;
    setIsEvaluating(true);

    try {
      // Intelligent evaluation: structure, symbols, and color recognition (proportions excluded, Nepal non-white shape check)
      const result = await evaluateDrawing(canvasElementRef.current, currentCountry, false, hintsUsed);
      setEvaluationResult(result);

      // Handle Speedrun Record Storage & Tiebreaker logic
      if (gameMode === 'speedrun' && elapsedTimeSeconds > 0) {
        setLastSpeedrunTime(elapsedTimeSeconds);
        const record = recordSpeedrunRun(
          currentCountry.id,
          result.score,
          elapsedTimeSeconds,
          googleUser?.name || 'Jugador Anónimo',
          googleUser?.picture
        );
        const rankInfo = getPlayerRank(currentCountry.id, record.id);
        setSpeedrunRankInfo(rankInfo);
      } else {
        setLastSpeedrunTime(undefined);
        setSpeedrunRankInfo(null);
      }

      // Sound & Stats updates (Strict: >= 90 required for streak and completion)
      const isSuccess = result.score >= 90;
      const isPerfect = result.score >= 95;

      if (soundEnabled) {
        if (isPerfect) {
          playSuccessSound(true);
        } else if (isSuccess) {
          playSuccessSound(false);
        } else {
          playFailSound();
        }
      }

      setStats((prev: GameStats) => {
        const newStreak = isSuccess ? prev.currentStreak + 1 : 0;
        const bestStreak = Math.max(prev.bestStreak, newStreak);
        const prevCountryBest = prev.completedFlags[currentCountry.id] || 0;
        const completedFlags = {
          ...prev.completedFlags,
          [currentCountry.id]: Math.max(prevCountryBest, result.score),
        };

        return {
          totalDrawn: prev.totalDrawn + 1,
          flagsCompleted: isSuccess && prevCountryBest < 90 ? prev.flagsCompleted + 1 : prev.flagsCompleted,
          perfectScores: isPerfect ? prev.perfectScores + 1 : prev.perfectScores,
          currentStreak: newStreak,
          bestStreak,
          completedFlags,
        };
      });
    } catch (err) {
      console.error('Evaluation error:', err);
    } finally {
      setIsEvaluating(false);
    }
  };

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && !evaluationResult && !isAtlasOpen && !isSpeedrunPickerOpen && !isSpeedrunLeaderboardOpen && !isInMenu && googleUser) {
        e.preventDefault();
        handleSubmitDrawing(0, 0);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [evaluationResult, isAtlasOpen, isSpeedrunPickerOpen, isSpeedrunLeaderboardOpen, isInMenu, googleUser]);

  const handleLogout = () => {
    clearUser();
    setGoogleUser(null);
    setIsInMenu(true);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-neutral-100 overflow-hidden font-sans">
      {/* 1. Google Authentication Gate Modal */}
      {!googleUser && (
        <GoogleLoginModal
          isOpen={!googleUser}
          onLoginSuccess={(user) => {
            setGoogleUser(user);
          }}
        />
      )}

      {/* 2. Main Menu or Game Workspace */}
      {googleUser && isInMenu ? (
        <MainMenu
          user={googleUser}
          stats={stats}
          mode={gameMode}
          onSelectMode={(m) => {
            setGameMode(m);
            if (m !== 'continente') setSelectedContinent(undefined);
          }}
          selectedContinent={selectedContinent}
          onSelectContinent={(c) => setSelectedContinent(c)}
          onStartGame={() => {
            handleNextRandom();
            setIsInMenu(false);
          }}
          onOpenAtlas={() => setIsAtlasOpen(true)}
          onOpenSpeedrunPicker={() => setIsSpeedrunPickerOpen(true)}
          onOpenSpeedrunLeaderboards={() => {
            setSpeedrunLeaderboardTargetCountry(currentCountry);
            setIsSpeedrunLeaderboardOpen(true);
          }}
          onLogout={handleLogout}
        />
      ) : googleUser ? (
        <>
          {/* Top Header */}
          <GameHeader
            currentCountry={currentCountry}
            mode={gameMode}
            onSelectMode={(m) => {
              setGameMode(m);
              handleNextRandom();
            }}
            stats={stats}
            onOpenAtlas={() => setIsAtlasOpen(true)}
            onNextRandom={handleNextRandom}
            onOpenMenu={() => setIsInMenu(true)}
            soundEnabled={soundEnabled}
            onToggleSound={() => {
              playClickSound();
              setSoundEnabled(!soundEnabled);
            }}
          />

          {/* Main Drawing Workspace */}
          <main className="flex-1 overflow-hidden relative">
            <DrawingCanvas
              key={`${currentCountry.id}-${speedrunRunKey}`} // forces clean canvas & timer reset
              country={currentCountry}
              onCanvasReady={handleCanvasReady}
              isEvaluating={isEvaluating}
              onSubmit={handleSubmitDrawing}
              onOpenMenu={() => setIsInMenu(true)}
              mode={gameMode}
              onOpenSpeedrunLeaderboard={() => {
                setSpeedrunLeaderboardTargetCountry(currentCountry);
                setIsSpeedrunLeaderboardOpen(true);
              }}
              onOpenSpeedrunPicker={() => setIsSpeedrunPickerOpen(true)}
            />
          </main>
        </>
      ) : null}

      {/* Evaluation Results Modal */}
      {evaluationResult && (
        <EvaluationModal
          country={currentCountry}
          result={evaluationResult}
          mode={gameMode}
          speedrunTime={lastSpeedrunTime}
          speedrunRankInfo={speedrunRankInfo}
          onRetry={(keepDrawing) => {
            setEvaluationResult(null);
            if (!keepDrawing) {
              setSpeedrunRunKey((k) => k + 1);
            }
          }}
          onNext={() => {
            setEvaluationResult(null);
            handleNextRandom();
          }}
          onSpeedrunRetry={() => {
            setEvaluationResult(null);
            setLastSpeedrunTime(undefined);
            setSpeedrunRankInfo(null);
            setSpeedrunRunKey((k) => k + 1);
          }}
          onOpenSpeedrunPicker={() => {
            setEvaluationResult(null);
            setIsSpeedrunPickerOpen(true);
          }}
        />
      )}

      {/* Atlas & Country Selector Modal (with Emojis only!) */}
      <CountrySelectorModal
        isOpen={isAtlasOpen}
        onClose={() => setIsAtlasOpen(false)}
        onSelectCountry={handleSelectCountry}
        completedFlags={stats.completedFlags}
        currentCountryId={currentCountry.id}
      />

      {/* Speedrun Flag Selection Modal */}
      <SpeedrunPickerModal
        isOpen={isSpeedrunPickerOpen}
        onClose={() => setIsSpeedrunPickerOpen(false)}
        onSelectCountry={handleSelectSpeedrunCountry}
        onOpenLeaderboardForCountry={(country) => {
          setSpeedrunLeaderboardTargetCountry(country);
          setIsSpeedrunLeaderboardOpen(true);
        }}
      />

      {/* Speedrun Leaderboard & Ranking Modal */}
      <SpeedrunLeaderboardModal
        isOpen={isSpeedrunLeaderboardOpen}
        onClose={() => setIsSpeedrunLeaderboardOpen(false)}
        initialCountry={speedrunLeaderboardTargetCountry || currentCountry}
        onSelectSpeedrunCountry={handleSelectSpeedrunCountry}
      />
    </div>
  );
}
